package com.jieli.ota.tool.dongle.util;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc  Dongle的错误码
 * @since 2022/5/16
 */
public class DongleError {
    public static final int UNKNOWN = 1;
    public static final int EXCEPTION = 2;
    public static final int COMMAND = 3;
    public static final int USB = 4;

    public static final int ERR_IN_PROGRESS = 20;
    public static final int ERR_NOT_FOUNT_DEVICE = 21;
    public static final int ERR_OPEN_USB = 22;
    public static final int ERR_PERMISSION_DENIED = 23;
    public static final int ERR_IN_OTA = 24;

    public static final int ERR_INVALID_PARAM = 30;

}
