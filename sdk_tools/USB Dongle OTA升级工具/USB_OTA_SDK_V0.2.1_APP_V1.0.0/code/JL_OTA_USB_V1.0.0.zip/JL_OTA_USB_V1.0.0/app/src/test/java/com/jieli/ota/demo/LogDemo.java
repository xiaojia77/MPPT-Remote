package com.jieli.ota.demo;

import com.jieli.rcsp.util.RcspLog;

import org.junit.Test;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc  Log类使用示例
 * @since 2022/5/17
 */
public class LogDemo {

    @Test
    public void configLog(){
        boolean isLog = RcspLog.isLog();  //是否开启打印

        RcspLog.setTagPrefix("ota"); //设置打印前缀, 方便过滤打印信息
        RcspLog.setIsLog(true);      //设置是否开启打印
    }

    @Test
    public void logLevel(){
        RcspLog.v("tag", "message");   //打印v等级log, verbose
        RcspLog.d("tag", "message");   //打印d等级log, debug
        RcspLog.i("tag", "message");   //打印i等级log, info
        RcspLog.w("tag", "message");   //打印w等级log, warning
        RcspLog.e("tag", "message");   //打印e等级log, error
    }

    @Test
    public void outputLog(){
        RcspLog.setLogOutput(new RcspLog.ILogOutput() {
            @Override
            public void output(String logcat) {
                //回调打印信息, 可以保存到文件中，方便查找问题
            }
        });
    }

}
