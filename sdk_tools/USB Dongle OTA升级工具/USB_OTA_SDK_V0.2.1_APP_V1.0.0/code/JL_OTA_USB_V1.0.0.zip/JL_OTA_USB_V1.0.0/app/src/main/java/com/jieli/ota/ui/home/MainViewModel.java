package com.jieli.ota.ui.home;

import android.content.Context;
import android.hardware.usb.UsbDevice;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jieli.ota.MainApplication;
import com.jieli.ota.callback.OnUpgradeCallback;
import com.jieli.ota.data.constant.OTAConstant;
import com.jieli.ota.data.constant.OTAError;
import com.jieli.ota.data.constant.UpgradeType;
import com.jieli.ota.data.model.AutoTestState;
import com.jieli.ota.data.model.OTAConfig;
import com.jieli.ota.data.model.OTAFinishState;
import com.jieli.ota.data.model.OTAParam;
import com.jieli.ota.data.model.OTAReconnectState;
import com.jieli.ota.data.model.OTATask;
import com.jieli.ota.data.model.OnlineDeviceResult;
import com.jieli.ota.data.model.OpenUsbResult;
import com.jieli.ota.data.model.OtaProgressState;
import com.jieli.ota.data.model.OtaState;
import com.jieli.ota.data.model.ReConnectMsg;
import com.jieli.ota.data.model.RemoteDeviceState;
import com.jieli.ota.data.model.UsbDeviceState;
import com.jieli.ota.tool.config.ConfigHelper;
import com.jieli.ota.tool.dongle.DongleManager;
import com.jieli.ota.tool.dongle.callback.OnDongleEventCallback;
import com.jieli.ota.tool.dongle.callback.OnResultListener;
import com.jieli.ota.tool.dongle.model.DongleInfo;
import com.jieli.ota.tool.dongle.model.OTADevice;
import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.ota.tool.dongle.util.DongleError;
import com.jieli.ota.tool.ota.OTAManager;
import com.jieli.ota.util.UIHelper;
import com.jieli.rcsp.data.device.Device;
import com.jieli.rcsp.util.DataFormatUtil;
import com.jieli.rcsp.util.RcspLog;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Created by zqjasonzhong on 2022/5/4.
 * 主页操作界面
 */
public class MainViewModel extends ViewModel {
    private final String tag = MainViewModel.class.getSimpleName();
    private final DongleManager dongleManager = DongleManager.getInstance();
    private final ConfigHelper configHelper = ConfigHelper.getInstance();

    MutableLiveData<UsbDeviceState> usbDeviceStateMLD = new MutableLiveData<>();
    MutableLiveData<OpenUsbResult> openUsbResultMLD = new MutableLiveData<>();
    MutableLiveData<OnlineDeviceResult> onlineDeviceResultMLD = new MutableLiveData<>();
    MutableLiveData<OtaState> otaStateMLD = new MutableLiveData<>();
    MutableLiveData<Boolean> isOTAMLD = new MutableLiveData<>();
    MutableLiveData<AutoTestState> autoTestStateMLD = new MutableLiveData<>();

    private final List<Integer> otaTaskList = new ArrayList<>();
    private volatile int reconnectState;
    private int retryCount = 0;  //重连USB次数

    private final String otaFileDir;
    private final String mouseOTAFileDir;
    private final String kbOTAFileDir;
    private final String dongleOTAFileDir;

    private final Handler mUIHandler = new Handler(Looper.getMainLooper());
    private volatile HandleOTATask mHandleOTATask;

    private static final int RECONNECT_STATE_IDLE = 0;
    private static final int RECONNECT_STATE_READY = 1;
    private static final int RECONNECT_STATE_OPEN = 2;

    public MainViewModel() {
        Context context = MainApplication.getContext();
        otaFileDir = UIHelper.createFilePath(context, OTAConstant.DIR_UPGRADE);
        mouseOTAFileDir = UIHelper.createFilePath(context, OTAConstant.DIR_UPGRADE, OTAConstant.DIR_MOUSE);
        kbOTAFileDir = UIHelper.createFilePath(context, OTAConstant.DIR_UPGRADE, OTAConstant.DIR_KB);
        dongleOTAFileDir = UIHelper.createFilePath(context, OTAConstant.DIR_UPGRADE, OTAConstant.DIR_DONGLE);
        dongleManager.addOnDongleEventCallback(mDongleEventCallback);
    }

    public void release() {
        mUIHandler.removeCallbacksAndMessages(null);
        otaTaskList.clear();
        if (mHandleOTATask != null) {
            mHandleOTATask.stopHandleThread();
            mHandleOTATask = null;
        }
        dongleManager.removeOnDongleEventCallback(mDongleEventCallback);
        dongleManager.release();
    }

    public boolean isSupportMultiDevicesOTA() {
        return configHelper.isSupportMultiDevicesOTA();
    }

    public boolean isOpenUsb() {
        return getOpenUsbDevice() != null;
    }

    public UsbDevice getOpenUsbDevice() {
        return dongleManager.getOpenUsbDevice();
    }

    public DongleInfo getDongleInfo() {
        return dongleManager.getDongleInfo();
    }

    /*打开USB设备通道*/
    public void openUsbDevice(int vid, int pid) {
        dongleManager.openUsbDevice(vid, pid, new OnResultListener<UsbDevice>() {
            @Override
            public void onResult(UsbDevice result) {
                RcspLog.i(tag, "openUsbDevice : >>> open usb success. " + reconnectState);
                retryCount = 0;
                if (reconnectState == RECONNECT_STATE_OPEN) {
                    OTAManager manager = dongleManager.getOtaManager(RemoteDevice.CHANNEL_USB);
                    if (manager != null && manager.isOTA()) {
                        RemoteDevice remoteDevice = dongleManager.findRemoteDeviceByChannel(manager.getChannelSeq());
                        if (remoteDevice != null) remoteDevice.setAuthPass(false);
                        manager.handleDeviceConnectedEvent(OTADevice.changeOTADevice(remoteDevice));
                    }
                    setReconnectState(RECONNECT_STATE_IDLE);
                }
                OpenUsbResult openUsbResult = new OpenUsbResult();
                openUsbResult.setResult(result);
                openUsbResultMLD.postValue(openUsbResult);
                OTAManager manager = dongleManager.getOtaManager(RemoteDevice.CHANNEL_USB);
                if (manager == null || !manager.isOTA()) clearOTATask();
//                obtainOnlineDevices();
            }

            @Override
            public void onFailed(int code, String message) {
                RcspLog.w(tag, "openUsbDevice : >>> open usb failed. code = " + code + ", " + message + ", retryCount = " + retryCount);
                if (code == DongleError.ERR_PERMISSION_DENIED && retryCount < 2) {
                    retryCount++;
                    //重试一次
                    mUIHandler.postDelayed(() -> dongleManager.openUsbDevice(vid, pid, this), 30);
                    return;
                }
                retryCount = 0;
                RcspLog.w(tag, "openUsbDevice : >>> open usb failed. over retry count. reconnectState " + reconnectState);
                if (reconnectState != RECONNECT_STATE_IDLE) {
                    OTAManager manager = dongleManager.getOtaManager(RemoteDevice.CHANNEL_USB);
                    if (manager != null && manager.isOTA()) {  //回连USB设备失败，中止OTA流程
                        RemoteDevice remoteDevice = dongleManager.findRemoteDeviceByChannel(manager.getChannelSeq());
                        if (remoteDevice != null) remoteDevice.setAuthPass(false);
                        manager.callbackDeviceConnectFailed(OTADevice.changeOTADevice(remoteDevice));
                    }
                    setReconnectState(RECONNECT_STATE_IDLE);
                }
                OpenUsbResult openUsbResult = new OpenUsbResult();
                openUsbResult.setCode(code);
                openUsbResult.setMessage(message);
                openUsbResultMLD.postValue(openUsbResult);
            }
        });
    }

    public void closeUsbDevice() {
        dongleManager.closeUseDevice(dongleManager.getOpenUsbDevice());
        OpenUsbResult openUsbResult = new OpenUsbResult();
        openUsbResult.setCode(DongleError.EXCEPTION);
        openUsbResult.setMessage("Use close usb.");
        openUsbResultMLD.postValue(openUsbResult);
    }

    /*获取在线设备信息*/
    public void obtainOnlineDevices(boolean isUser) {
        if (isOTA() && isUser) {
            OnlineDeviceResult result = new OnlineDeviceResult();
            result.setCode(DongleError.ERR_IN_OTA);
            result.setMessage("Do not refresh the device list when the upgrade is in progress.");
            onlineDeviceResultMLD.postValue(result);
            return;
        }
        dongleManager.obtainOnLineDevices(new OnResultListener<Boolean>() {
            @Override
            public void onResult(Boolean result) {

            }

            @Override
            public void onFailed(int code, String message) {
                OnlineDeviceResult result = new OnlineDeviceResult();
                result.setCode(code);
                result.setMessage(message);
                onlineDeviceResultMLD.postValue(result);
            }
        });
    }

    public String getOtaFileDir() {
        return otaFileDir;
    }

    public String getOtaFileDir(String deviceName) {
        String otaFilePathDir = otaFileDir;
        if (TextUtils.isEmpty(deviceName)) return otaFilePathDir;
        if (deviceName.startsWith(OTAConstant.PREFIX_MOUSE)) {
            otaFilePathDir = mouseOTAFileDir;
        } else if (deviceName.startsWith(OTAConstant.PREFIX_KEYBOARD)) {
            otaFilePathDir = kbOTAFileDir;
        } else if (deviceName.startsWith(OTAConstant.PREFIX_DONGLE)) {
            otaFilePathDir = dongleOTAFileDir;
        }
        return otaFilePathDir;
    }

    public boolean isOTA() {
        return !otaTaskList.isEmpty();
    }

    public boolean isOTA(int channel) {
        OTAManager otaManager = dongleManager.getOtaManager(channel);
        return otaManager != null && otaManager.isOTA();
    }

    public void startOTA(@NonNull List<RemoteDeviceState> deviceStates) {
        List<OTAParam> otaParams = new ArrayList<>();
        for (RemoteDeviceState deviceState : deviceStates) {
            otaParams.add(new OTAParam(deviceState.getDevice().getChannelID(), deviceState.getOtaFilePath()));
        }
        startDeviceOTA(otaParams);
    }

    public void reconnectDevice(int channel, ReConnectMsg reConnectMsg) {
        if (channel == RemoteDevice.CHANNEL_USB) {
            setReconnectState(RECONNECT_STATE_READY);
            boolean isOnLine = usbDeviceStateMLD.getValue() != null && usbDeviceStateMLD.getValue().isOnLine();
            tryToReconnectDongle(isOnLine);
            return;
        }
        RemoteDevice device = dongleManager.findRemoteDeviceByChannel(channel);
        RcspLog.e(tag, "reconnectDevice : " + channel + ", " + reConnectMsg + ", " + device);
        if (device != null && device.getState() != OTAConstant.STATE_DEVICE_OFFLINE) {
            dongleManager.disconnectRemoteDevice(channel, null);
            SystemClock.sleep(1000);
        }
        RemoteDevice remoteDevice = new RemoteDevice(channel);
        remoteDevice.setState(OTAConstant.STATE_DEVICE_INIT_RCSP);
        remoteDevice.setMac(RemoteDevice.getMacByDesc(channel, reConnectMsg.getDevice().getMac()));
        RcspLog.e(tag, "reconnectDevice : mac = " + DataFormatUtil.byte2HexStr(remoteDevice.getMac()));
        dongleManager.connectRemoteDevice(remoteDevice, new OnResultListener<Boolean>() {
            @Override
            public void onResult(Boolean result) {
                RcspLog.d(tag, "reconnectDevice : onResult = " + result);
            }

            @Override
            public void onFailed(int code, String message) {
                RcspLog.e(tag, "reconnectDevice : onFailed = " + code + ", " + message);
            }
        });
    }

    private void startDeviceOTA(List<OTAParam> otaParams) {
        if (isOTA()) {
            RcspLog.e(tag, "startOTA : Ota is in progress.");
            return;
        }
        for (OTAParam otaParam : otaParams) {
            otaTaskList.add(otaParam.getChannel());
        }
        List<OTATask> taskList = new ArrayList<>();
        for (OTAParam otaParam : otaParams) {
            int channel = otaParam.getChannel();
            OTAManager otaManager = dongleManager.getOtaManager(channel);
            if (null == otaManager) {
                removeOTATask(channel);
                continue;
            }
            OTAConfig config = new OTAConfig()
                    .setCommunicationWay(channel == RemoteDevice.CHANNEL_USB ? OTAConfig.COMMUNICATION_WAY_USB : OTAConfig.COMMUNICATION_WAY_BLE)
                    .setSupportNewRebootWay(false)
                    .setUpdateFilePath(otaParam.getOtaFilePath());
            taskList.add(new OTATask(channel, config));
//            otaManager.startOTA(config, new CustomOnUpgradeCallback(channel));
        }
        if (!taskList.isEmpty()) {
            isOTAMLD.setValue(true);
            if (null == mHandleOTATask) {
                mHandleOTATask = new HandleOTATask();
                mHandleOTATask.start();
            }
            OTATask usbOTATask = null;
            for (OTATask task : taskList) {
                if (task.getChannel() == RemoteDevice.CHANNEL_USB) {
                    usbOTATask = task;
                    continue;
                }
                mHandleOTATask.addOTATask(task);
            }
            if (null != usbOTATask) {
                mHandleOTATask.addOTATask(usbOTATask);
            }
        }
    }

    private void setReconnectState(int reconnectState) {
        this.reconnectState = reconnectState;
    }

    private void removeOTATask(int channel) {
        if (otaTaskList.remove((Integer) channel)) {
            if (otaTaskList.isEmpty()) {
                isOTAMLD.setValue(false);
            }
        }
    }

    private void clearOTATask() {
        if (!otaTaskList.isEmpty()) {
            otaTaskList.clear();
            isOTAMLD.postValue(false);
        }
    }

    private void tryToReconnectDongle(boolean isOnLine) {
        if (isOnLine && reconnectState == RECONNECT_STATE_READY) { //USB回连成功, 重新打开通道
            setReconnectState(RECONNECT_STATE_OPEN);
            RcspLog.i(tag, "onUsbDeviceState : >>> USB reconnect ok. open usb");
            openUsbDevice(OTAConstant.USB_VID, OTAConstant.USB_PID);
        }
    }

    private final OnDongleEventCallback mDongleEventCallback = new OnDongleEventCallback() {
        @Override
        public void onUsbDeviceState(UsbDevice device, boolean isOnLine) {
            usbDeviceStateMLD.postValue(new UsbDeviceState(device, isOnLine));
            RcspLog.d(tag, String.format(Locale.getDefault(), "onUsbDeviceState : >>> USB[%s] : %s, state : %d", device, isOnLine, reconnectState));
            tryToReconnectDongle(isOnLine);
        }

        @Override
        public void onRemoteDevicesChange(List<RemoteDevice> list) {
            RcspLog.i(tag, "onRemoteDevicesChange : >>> " + list);
            List<RemoteDevice> filterList = new ArrayList<>();
            for (RemoteDevice device : list) {
                if (device.getState() >= OTAConstant.STATE_DEVICE_INIT_RCSP) {
                    filterList.add(device);
                }
            }
            OnlineDeviceResult result = new OnlineDeviceResult();
            result.setResult(filterList);
            onlineDeviceResultMLD.postValue(result);
        }
    };

    private class CustomOnUpgradeCallback implements OnUpgradeCallback {
        private final int channel;
        private long startTime = 0;

        public CustomOnUpgradeCallback(int channel) {
            this.channel = channel;
        }

        @Override
        public void onStartOTA(Device device) {
            startTime = getCurrentTime();
            OtaState state = new OtaProgressState(channel, 0, 0.0f);
            state.setOtaTime(0);
            otaStateMLD.postValue(state);
        }

        @Override
        public void onNeedReconnect(Device device, ReConnectMsg reConnectMsg) {
            RcspLog.w(tag, "onNeedReconnect : " + device + ", " + reConnectMsg);
            OtaState state = new OTAReconnectState(channel, reConnectMsg);
            state.setOtaTime(getOTAUseTime(startTime));
            otaStateMLD.postValue(state);
        }

        @Override
        public void onProgress(Device device, UpgradeType type, float progress) {
            OtaState state = new OtaProgressState(channel, type.getType(), progress);
            state.setOtaTime(getOTAUseTime(startTime));
            otaStateMLD.postValue(state);
        }

        @Override
        public void onStopOTA(Device device) {
            RcspLog.w(tag, "onStopOTA : " + device + ", OTA is success.");
            removeOTATask(channel);
            setReconnectState(RECONNECT_STATE_IDLE);
            OtaState state = new OTAFinishState(channel, OTAError.ERROR_NONE, "OTA is success.");
            state.setOtaTime(getOTAUseTime(startTime));
            otaStateMLD.postValue(state);
            if (mHandleOTATask != null) {
                mHandleOTATask.unLock();
            }
            startTime = 0;
            mUIHandler.postDelayed(() -> {
                //升级完成，通知dongle断开远端设备的通道连接
                dongleManager.disconnectRemoteDevice(channel, null);
            }, 1000);
        }

        @Override
        public void onCancelOTA(Device device) {
            removeOTATask(channel);
            setReconnectState(RECONNECT_STATE_IDLE);
            int code = OTAError.ERROR_OTA_USE_CANCEL;
            OtaState state = new OTAFinishState(channel, code, OTAError.getErrorDesc(code));
            state.setOtaTime(getOTAUseTime(startTime));
            otaStateMLD.setValue(state);
            if (mHandleOTATask != null) {
                mHandleOTATask.unLock();
            }
            startTime = 0;
        }

        @Override
        public void onError(Device device, int error, String message) {
            RcspLog.w(tag, "onError : " + device + ", error = " + error + ", " + message);
            removeOTATask(channel);
            setReconnectState(RECONNECT_STATE_IDLE);
            OtaState state = new OTAFinishState(channel, error, message);
            state.setOtaTime(getOTAUseTime(startTime));
            otaStateMLD.postValue(state);
            if (mHandleOTATask != null) {
                mHandleOTATask.unLock();
            }
            startTime = 0;
        }

        private long getCurrentTime() {
            return System.currentTimeMillis();
        }

        private int getOTAUseTime(long startTime) {
            if (startTime <= 0) return 0;
            long currentTime = getCurrentTime();
            if (currentTime < startTime) return 0;
            return Math.round((currentTime - startTime) / 1000F);
        }
    }

    private final class HandleOTATask extends Thread {
        private final String TAG = HandleOTATask.class.getSimpleName();
        private final LinkedBlockingQueue<OTATask> mTaskQueue = new LinkedBlockingQueue<>();
        private volatile boolean isRunning;
        private volatile boolean isTaskLock;
        private volatile boolean isQueueEmpty = true;

        private volatile OTATask mOTATask;

        public HandleOTATask() {
            super("HandleOTATask");
        }

        @Override
        public synchronized void start() {
            super.start();
            isRunning = true;
        }

        @Override
        public void run() {
            synchronized (mTaskQueue) {
                while (isRunning) {
                    mOTATask = null;
                    isQueueEmpty = mTaskQueue.isEmpty();
                    if (isQueueEmpty) {
                        RcspLog.i(TAG, "Task queue is empty,so thread will be sleep.");
                        clearOTATask();
                        lock();
                    } else {
                        OTATask task = mTaskQueue.poll();
                        if (null != task) {
                            mOTATask = task;
                            RcspLog.d(TAG, "Obtain task = " + task);
                            OTAManager otaManager = dongleManager.getOtaManager(task.getChannel());
                            if (null == otaManager) {
                                RcspLog.i(TAG, "not found ota manager." + task.getChannel());
                                continue;
                            }
                            RcspLog.d(TAG, "Ready to start ota. " + task.getChannel() + ", " + isTaskLock);
                            otaManager.startOTA(task.getConfig(), new CustomOnUpgradeCallback(task.getChannel()));
                            RcspLog.d(TAG, "isTaskLock " + isTaskLock);
                            if (!isTaskLock) {
                                lock();
                            }
                        }
                    }
                }
            }
            isRunning = false;
            isTaskLock = false;
            mTaskQueue.clear();
            mHandleOTATask = null;
            interrupt();
            RcspLog.i(TAG, "Handle thread is died.");
        }

        public void addOTATask(OTATask task) {
            if (null == task || !isRunning) return;
            boolean ret = false;
            try {
                RcspLog.d(TAG, "addOTATask :  " + task + ", " + Thread.currentThread().getName());
                mTaskQueue.put(task);
                RcspLog.i(TAG, "addOTATask : success. " + Thread.currentThread().getName());
                ret = true;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (ret && isQueueEmpty) {
                isQueueEmpty = false;
                unLock();
            }
        }

        public synchronized void stopHandleThread() {
            mTaskQueue.clear();
            isRunning = false;
            if (mOTATask != null) {
                OTAManager otaManager = dongleManager.getOtaManager(mOTATask.getChannel());
                if (null != otaManager) {
                    otaManager.destroy();
                }
            }
            unLock();
        }

        private void lock() {
            synchronized (mTaskQueue) {
                if (isTaskLock) {
                    RcspLog.i(TAG, "lock >>>> it is locked.");
                    return;
                }
                isTaskLock = true;
                RcspLog.d(TAG, "lock >>>> ready to lock");
                try {
                    mTaskQueue.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                RcspLog.d(TAG, "lock >>>> release lock");
                isTaskLock = false;
            }
        }

        private void unLock() {
            synchronized (mTaskQueue) {
                if (!isTaskLock) return;
                RcspLog.d(TAG, "unLock >>>> ");
                mTaskQueue.notify();
            }
        }
    }
}
