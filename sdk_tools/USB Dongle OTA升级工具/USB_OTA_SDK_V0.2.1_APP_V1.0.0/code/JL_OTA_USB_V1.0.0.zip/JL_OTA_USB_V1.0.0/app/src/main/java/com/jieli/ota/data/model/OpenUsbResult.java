package com.jieli.ota.data.model;

import android.hardware.usb.UsbDevice;

/**
 * Created by zqjasonzhong on 2022/5/4.
 */

public class OpenUsbResult extends OpResult<UsbDevice> {
}
