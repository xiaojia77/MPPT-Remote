package com.jieli.ota.data.model;

/**
 * Created by zqjasonzhong on 2022/5/4.
 */

public class OpResult<T> {
   private T result;
   private int code;
   private String message;

   public T getResult() {
      return result;
   }

   public void setResult(T result) {
      this.result = result;
   }

   public int getCode() {
      return code;
   }

   public void setCode(int code) {
      this.code = code;
   }

   public String getMessage() {
      return message;
   }

   public void setMessage(String message) {
      this.message = message;
   }

   public boolean isSuccess(){
      return code == 0 && result != null;
   }

   @Override
   public String toString() {
      return "OpResult{" +
              "result=" + result +
              ", code=" + code +
              ", message='" + message + '\'' +
              '}';
   }
}
