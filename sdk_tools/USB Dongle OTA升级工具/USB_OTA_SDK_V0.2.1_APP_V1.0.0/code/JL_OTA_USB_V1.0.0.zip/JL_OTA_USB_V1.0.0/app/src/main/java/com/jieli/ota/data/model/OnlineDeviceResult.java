package com.jieli.ota.data.model;

import com.jieli.ota.tool.dongle.model.RemoteDevice;

import java.util.List;

/**
 * Created by zqjasonzhong on 2022/5/4.
 */

public class OnlineDeviceResult extends OpResult<List<RemoteDevice>> {
}
