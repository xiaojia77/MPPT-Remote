package com.jieli.ota.tool.ota;

import android.hardware.usb.UsbDevice;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.jieli.ota.MainApplication;
import com.jieli.ota.data.constant.OTAConstant;
import com.jieli.ota.impl.OTAImpl;
import com.jieli.ota.tool.dongle.DongleManager;
import com.jieli.ota.tool.dongle.callback.OnDongleEventCallback;
import com.jieli.ota.tool.dongle.callback.OnResultListener;
import com.jieli.ota.tool.dongle.model.DongleInfo;
import com.jieli.ota.tool.dongle.model.OTADevice;
import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.ota.tool.ota.bean.OTAOption;
import com.jieli.rcsp.data.constant.Connection;
import com.jieli.rcsp.data.device.Device;
import com.jieli.rcsp.data.device.DeviceInfo;
import com.jieli.rcsp.impl.RcspAuth;
import com.jieli.rcsp.util.RcspLog;

import java.util.List;
import java.util.Locale;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OTA功能实现
 * @since 2022/4/29
 */
public class OTAManager extends OTAImpl {
    private static final String TAG = OTAManager.class.getSimpleName();
    private final DongleManager dongleManager = DongleManager.getInstance();
    private final Object lock = new Object();     //同步锁
    private volatile boolean isLock;              //加锁标志
    private volatile int sendResult;              //发送数据结果
    private final OTAOption otaOption;            //OTA配置项
    private final RcspAuth rcspAuth;              //设备认证实现类

    //记录当前通道的状态，避免重复状态处理
    private volatile Connection mConnection = Connection.CONNECTION_DISCONNECT;

    private static final int WAIT_CMD_RESULT_TIMEOUT = 5 * 1000;
    private static final int SEND_STATE_IDLE = 0;
    private static final int SEND_STATE_SUCCESS = 1;
    private static final int SEND_STATE_FAILED = 2;

    public OTAManager(@NonNull OTAOption option) {
        this.otaOption = option;
        rcspAuth = new RcspAuth(this::sendDataToDevice, new RcspAuth.OnRcspAuthListener() {
            @Override
            public void onInitResult(boolean result) {
                RcspLog.i(TAG, "RcspAuth init : " + result);
            }

            @Override
            public void onAuthSuccess(Device device) {
                RcspLog.i(TAG, "onAuthSuccess : " + device);
                sendAuthFlag(true);
                setDeviceAuthPass(true);
                handleDeviceConnectedEvent((OTADevice) device);
            }

            @Override
            public void onAuthFailed(Device device, int code, String message) {
                RcspLog.w(TAG, String.format(Locale.getDefault(), "onAuthFailed : %s, code = %d, %s", device, code, message));
                sendAuthFlag(false);
                callbackDeviceConnectFailed((OTADevice) device);
                //提示认证失败
                Toast.makeText(MainApplication.getContext(), String.format(Locale.getDefault(), "Channel[%d] 设备认证失败, 错误码:%d, 错误描述:%s",
                        getChannelSeq(), code, message), Toast.LENGTH_LONG).show();
            }
        });
        RcspLog.w(TAG, "init OTAManager = " + this + ", channel = " + getChannelSeq());
        if (!option.isUseAuthProgress()) {
            sendAuthFlag(true);
        }
        dongleManager.addOnDongleEventCallback(mDongleEventCallback);
    }

    @Override
    public boolean sendDataToDevice(Device device, byte[] data) {
        RemoteDevice remoteDevice = dongleManager.findRemoteDeviceByOTADevice((OTADevice) device);
        if (null == remoteDevice) {
            RcspLog.e(TAG, "sendDataToDevice : no found remote device. " + device);
            return false;
        }
        setSendResult(SEND_STATE_IDLE, false); //预设值 --- 空闲状态
        dongleManager.sendRcspData(remoteDevice, data, new OnResultListener<Boolean>() {
            @Override
            public void onResult(Boolean result) {
                RcspLog.d(TAG, "sendDataToDevice : send rcsp data success.");
                setSendResult(SEND_STATE_SUCCESS); //设置发送成功
            }

            @Override
            public void onFailed(int code, String message) {
                RcspLog.w(TAG, "sendDataToDevice : send rcsp data error. code = " + code + ", " + message);
                setSendResult(SEND_STATE_FAILED); //设置发送失败
            }
        });
        RcspLog.d(TAG, "sendDataToDevice : ready lock " + isLock + ", sendResult = " + sendResult);
        if (sendResult == SEND_STATE_IDLE) { //如果是预设值，就等待
            lock(WAIT_CMD_RESULT_TIMEOUT);
        }
        RcspLog.d(TAG, "sendDataToDevice : release lock. sendResult = " + sendResult);
        return sendResult == SEND_STATE_SUCCESS;
    }

    @Override
    public void destroy() {
        RcspLog.w(tag, "OTA >>>>>> destroy");
        super.destroy();
        setSendResult(SEND_STATE_IDLE);
        mConnection = Connection.CONNECTION_DISCONNECT;
        rcspAuth.destroy();
        dongleManager.removeOnDongleEventCallback(mDongleEventCallback);
    }

    public int getChannelSeq() {
        return otaOption.getChannel();
    }

    public DeviceInfo getDeviceInfo() {
        return getDeviceInfo(getUsingDevice());
    }

    private RemoteDevice getTargetDevice() {
        return dongleManager.findRemoteDeviceByChannel(getChannelSeq());
    }

    private void setSendResult(int sendResult) {
        setSendResult(sendResult, true);
    }

    private void setSendResult(int sendResult, boolean isNeedUnLock) {
        this.sendResult = sendResult;
        if (isNeedUnLock) {
            unLock();
        }
    }

    private boolean isDeviceAuthPass() {
        if (!otaOption.isUseAuthProgress()) return true;
        return otaOption.isDeviceAuthPass();
    }

    private void setDeviceAuthPass(boolean deviceAuthPass) {
        otaOption.setDeviceAuthPass(deviceAuthPass);
    }

    private boolean isNotNeedSendAuthFlag() {
        if (getChannelSeq() == RemoteDevice.CHANNEL_USB) {
            //处于dongle的loader状态可以不发
            return dongleManager.getDongleInfo() != null && dongleManager.getDongleInfo().getEnvStatus() == DongleInfo.ENV_LOADER;
        }
        return false;
    }

    private void sendAuthFlag(boolean isAuthed) {
        if (isNotNeedSendAuthFlag()) return;
        dongleManager.setChannelAuthFlag(getChannelSeq(), isAuthed, null);
    }

    private void lock(long timeout) {
        synchronized (lock) {
            if (isLock) return;
            try {
                isLock = true;
                RcspLog.d(tag, "sendDataToDevice: lock : " + isLock);
                if (timeout > 0) {
                    lock.wait(timeout);
                } else {
                    lock.wait();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            isLock = false;
        }
    }

    private void unLock() {
        synchronized (lock) {
            if (!isLock) return;
            lock.notify();
        }
    }

    public void handleDeviceConnectedEvent(OTADevice device) {
        boolean isDeviceAuthPass = isDeviceAuthPass();
        RcspLog.d(tag, "handleDeviceConnectedEvent : >>> " + device + ", isDeviceAuthPass = " + isDeviceAuthPass + ", Connection = " + mConnection);
        if (isDeviceAuthPass) {  //设备认证通过
            mConnection = Connection.CONNECTION_CONNECTED;
            transmitDeviceStatus(device, Connection.CONNECTION_CONNECTED);
        } else {
            if (mConnection != Connection.CONNECTION_CONNECTING) { //状态限制，因为可能重复回调设备状态
                rcspAuth.stopAuth(device, false);
                if (!rcspAuth.startAuth(device)) {
                    //开启设备认证失败
                    RcspLog.w(tag, "handleDeviceConnectedEvent :  >>>  start auth progress failed.");
                    callbackDeviceConnectFailed(device);
                } else {
                    mConnection = Connection.CONNECTION_CONNECTING;
                }
            } else {
                RcspLog.d(tag, "handleDeviceConnectedEvent : >>> same connection. skip! " + mConnection);
            }
        }
    }

    public void callbackDeviceConnectFailed(OTADevice device) {
        setDeviceAuthPass(false);
        mConnection = Connection.CONNECTION_DISCONNECT;
        transmitDeviceStatus(device, Connection.CONNECTION_DISCONNECT);
    }

    private final OnDongleEventCallback mDongleEventCallback = new OnDongleEventCallback() {
        @Override
        public void onUsbDeviceState(UsbDevice device, boolean isOnLine) {
            if (!isOnLine && getTargetDevice() != null) { //设备下线
                //透传设备断开状态
                callbackDeviceConnectFailed(OTADevice.changeOTADevice(getTargetDevice()));
            }
        }

        @Override
        public void onRemoteDevicesChange(List<RemoteDevice> list) {
            if (list.isEmpty()) {
                RcspLog.i(TAG, "onRemoteDevicesChange : list is empty.");
                if (getUsingDevice() != null)
                    callbackDeviceConnectFailed((OTADevice) getUsingDevice());
                return;  //没有远端设备，跳过
            }
            RemoteDevice device = null;
            for (RemoteDevice remoteDevice : list) {
                if (remoteDevice.getChannelID() == getChannelSeq()) {
                    device = remoteDevice;
                    break;
                }
            }
            if (null == device) { //没有找到目标通道的远端设备，跳过
                RcspLog.i(TAG, "onRemoteDevicesChange : no found device. channel = " + getChannelSeq());
                if (getUsingDevice() != null && isOTA()) {
                    callbackDeviceConnectFailed((OTADevice) getUsingDevice());
                }
                return;
            }
            if (dongleManager.getOpenUsbDevice() == null) {
                RcspLog.i(TAG, "onRemoteDevicesChange : dongle not connect. channel = " + getChannelSeq());
                if (getUsingDevice() != null)
                    callbackDeviceConnectFailed((OTADevice) getUsingDevice());
                return;
            }
            OTADevice otaDevice = OTADevice.changeOTADevice(device);
            RcspLog.i(TAG, "onRemoteDevicesChange : =====>>>> " + device + ", otaDevice = " + otaDevice);
            if (device.getState() == OTAConstant.STATE_DEVICE_OFFLINE) {
                callbackDeviceConnectFailed(otaDevice);
            } else if (device.getState() == OTAConstant.STATE_DEVICE_ONLINE) {
                handleDeviceConnectedEvent(otaDevice);
            }
        }

        @Override
        public void onRcspData(int channel, byte[] data) {
            if (channel != getChannelSeq()) {
                RcspLog.w(TAG, "onRcspData : channel is not match. channel : " + channel + ", target channel : " + getChannelSeq());
                return; //通道号与目标通道号不一致，跳过
            }
            OTADevice otaDevice = OTADevice.changeOTADevice(getTargetDevice());
            if (!isDeviceAuthPass()) {  //设备还没认证，处理认证数据
                rcspAuth.handleAuthData(otaDevice, data);
                return;
            }
            //透传接收到的设备数据
            transmitDeviceData(otaDevice, data);
        }
    };

    @Override
    public String toString() {
        return "OTAManager{" +
                "mOTAConfig=" + mOTAConfig +
                ", isOTA=" + isOTA() +
                ", isDeviceConnected=" + isDeviceConnected() +
                ", UsingDevice=" + getUsingDevice() +
                '}';
    }
}
