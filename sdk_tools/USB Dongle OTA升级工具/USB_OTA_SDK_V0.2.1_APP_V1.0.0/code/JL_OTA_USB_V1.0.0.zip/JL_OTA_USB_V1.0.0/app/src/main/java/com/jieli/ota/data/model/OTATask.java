package com.jieli.ota.data.model;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OTA任务
 * @since 2022/10/12
 */
public class OTATask {
    private final int channel;
    private final OTAConfig config;

    public OTATask(int channel, OTAConfig config) {
        this.channel = channel;
        this.config = config;
    }

    public int getChannel() {
        return channel;
    }

    public OTAConfig getConfig() {
        return config;
    }

    @Override
    public String toString() {
        return "OTATask{" +
                "channel=" + channel +
                ", config=" + config +
                '}';
    }
}
