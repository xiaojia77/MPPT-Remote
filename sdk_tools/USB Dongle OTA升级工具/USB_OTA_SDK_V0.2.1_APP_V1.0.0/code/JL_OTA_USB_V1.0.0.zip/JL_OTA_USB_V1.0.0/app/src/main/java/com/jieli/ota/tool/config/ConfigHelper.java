package com.jieli.ota.tool.config;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.jieli.ota.MainApplication;
import com.jieli.ota.data.constant.OTAConstant;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 应用配置辅助类
 * @since 2022/5/9
 */
public class ConfigHelper {
    private volatile static ConfigHelper instance;
    private final SharedPreferences preferences;

    private static final String KEY_USE_AUTH = "key_use_auth";
    private static final String KEY_MULTI_DEVICES_OTA = "key_multi_devices_ota";

    private ConfigHelper(@NonNull Context context) {
        this.preferences = context.getApplicationContext().getSharedPreferences("ota_config_data", Context.MODE_PRIVATE);
    }

    public static ConfigHelper getInstance() {
        if (null == instance) {
            synchronized (ConfigHelper.class) {
                if (null == instance) {
                    instance = new ConfigHelper(MainApplication.getContext());
                }
            }
        }
        return instance;
    }

    public void release() {
        instance = null;
    }

    public boolean isUseAuth() {
        return preferences.getBoolean(KEY_USE_AUTH, OTAConstant.IS_USE_AUTH);
    }

    public void setIsUseAuth(boolean isUseAuth) {
        preferences.edit().putBoolean(KEY_USE_AUTH, isUseAuth).apply();
    }

    public boolean isSupportMultiDevicesOTA() {
        return preferences.getBoolean(KEY_MULTI_DEVICES_OTA, OTAConstant.MULTI_DEVICES_OTA);
    }

    public void setSupportMultiDevicesOTA(boolean isSupportMultiDevicesOTA) {
        preferences.edit().putBoolean(KEY_MULTI_DEVICES_OTA, isSupportMultiDevicesOTA).apply();
    }

    /*public void clear() {
        preferences.edit().clear().apply();
    }*/
}
