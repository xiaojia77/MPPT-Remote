package com.jieli.ota.data.model;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc  OTA参数
 * @since 2022/10/11
 */
public class OTAParam {
    private final int channel;
    private final String otaFilePath;

    public OTAParam(int channel, String otaFilePath) {
        this.channel = channel;
        this.otaFilePath = otaFilePath;
    }

    public int getChannel() {
        return channel;
    }

    public String getOtaFilePath() {
        return otaFilePath;
    }

    @Override
    public String toString() {
        return "OTAParam{" +
                "channel=" + channel +
                ", otaFilePath='" + otaFilePath + '\'' +
                '}';
    }
}
