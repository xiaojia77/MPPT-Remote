package com.jieli.ota.ui.adapter;

import android.annotation.SuppressLint;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.jieli.ota.R;
import com.jieli.ota.util.UIHelper;

import java.io.File;

/**
 * 文件适配器
 */
public class FileAdapter extends BaseQuickAdapter<File, BaseViewHolder> {
    private int selectedPos = -1;

    public FileAdapter() {
        super(R.layout.item_file);
    }

    public File getSelectedPos() {
        if (selectedPos < 0) return null;
        return getItem(selectedPos);
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setSelectedPos(int selectedPos) {
        if (this.selectedPos != selectedPos) {
            this.selectedPos = selectedPos;
            notifyDataSetChanged();
        }
    }

    @Override
    protected void convert(@NonNull BaseViewHolder viewHolder, File file) {
        if (null == file) return;
        viewHolder.setText(R.id.tv_file_name, file.getName());
        viewHolder.setText(R.id.tv_file_size, UIHelper.getFileSizeDesc(file.length()));
        final int position = getItemPosition(file);
        ImageView imageView = viewHolder.getView(R.id.iv_select_flag);
        imageView.setVisibility(position == selectedPos ? View.VISIBLE : View.INVISIBLE);
        viewHolder.setVisible(R.id.view_file_line, position != (getData().size() - 1));
    }
}
