package com.jieli.ota.tool.dongle.model;

import android.hardware.usb.UsbDevice;

import com.jieli.ota.tool.dongle.callback.OnResultListener;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc  开启USB参数
 * @since 2022/5/9
 */
public class OpenUsbParam {
    private final int vid;
    private final int pid;
    private final OnResultListener<UsbDevice> listener;

    public OpenUsbParam(int vid, int pid, OnResultListener<UsbDevice> listener) {
        this.vid = vid;
        this.pid = pid;
        this.listener = listener;
    }

    public int getVid() {
        return vid;
    }

    public int getPid() {
        return pid;
    }

    public OnResultListener<UsbDevice> getListener() {
        return listener;
    }
}
