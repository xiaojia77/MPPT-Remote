package com.jieli.ota.data.model;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OTA状态
 * @since 2022/5/5
 */
public class OtaState {
    private final int channel;
    private final int state;
    private int otaTime;

    public OtaState(int channel, int state) {
        this.channel = channel;
        this.state = state;
    }

    public int getChannel() {
        return channel;
    }

    public int getState() {
        return state;
    }

    public int getOtaTime() {
        return otaTime;
    }

    public void setOtaTime(int otaTime) {
        this.otaTime = otaTime;
    }

    @Override
    public String toString() {
        return "OtaState{" +
                "channel=" + channel +
                ", state=" + state +
                ", otaTime=" + otaTime +
                '}';
    }
}
