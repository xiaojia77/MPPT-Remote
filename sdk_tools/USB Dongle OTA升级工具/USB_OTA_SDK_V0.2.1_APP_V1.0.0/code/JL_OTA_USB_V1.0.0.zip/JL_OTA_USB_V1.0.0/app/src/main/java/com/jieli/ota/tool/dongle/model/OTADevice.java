package com.jieli.ota.tool.dongle.model;

import com.jieli.rcsp.data.device.Device;

import java.util.Objects;

/**
 * Created by zqjasonzhong on 2022/5/1.
 */
public class OTADevice extends Device {
    private final int channelSeq;

    public OTADevice(int channelSeq, String mac) {
        super(mac);
        this.channelSeq = channelSeq;
    }

    public static OTADevice changeOTADevice(RemoteDevice device) {
        if(null == device) return null;
        return new OTADevice(device.getChannelID(), device.getMacDesc());
    }

    public int getChannelSeq() {
        return channelSeq;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OTADevice otaDevice = (OTADevice) o;
        return channelSeq == otaDevice.channelSeq;
    }

    @Override
    public int hashCode() {
        return Objects.hash(channelSeq);
    }

    @Override
    public String toString() {
        return "OTADevice{" +
                "channelSeq=" + channelSeq +
                ", mac='" + getMac() + '\'' +
                '}';
    }
}
