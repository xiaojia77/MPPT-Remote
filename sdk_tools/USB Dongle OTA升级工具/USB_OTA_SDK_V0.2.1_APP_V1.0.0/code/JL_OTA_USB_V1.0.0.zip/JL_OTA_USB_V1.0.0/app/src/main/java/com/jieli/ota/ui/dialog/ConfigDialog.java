package com.jieli.ota.ui.dialog;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jieli.ota.BuildConfig;
import com.jieli.ota.MainApplication;
import com.jieli.ota.R;
import com.jieli.ota.databinding.DialogConfigBinding;
import com.jieli.ota.tool.config.ConfigHelper;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 配置弹窗
 * @since 2022/5/9
 */
public class ConfigDialog extends BaseDialogFragment {
    private DialogConfigBinding mBinding;
    private final ConfigHelper mConfigHelper = ConfigHelper.getInstance();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        requireDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = requireDialog().getWindow();
        if (window != null) {
            //去掉dialog默认的padding
            window.getDecorView().setPadding(0, 0, 0, 0);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.round(0.9f * getScreenWidth());
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            //设置dialog的动画
//                lp.windowAnimations = R.style.BottomToTopAnim;
            window.setAttributes(lp);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        mBinding = DialogConfigBinding.bind(inflater.inflate(R.layout.dialog_config, container));
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setCancelable(true);
        initUI();
    }

    private void initUI() {
        mBinding.btnConfigCancel.setOnClickListener(v -> dismiss());
        mBinding.btnConfigSure.setOnClickListener(v -> saveConfig());
        if (BuildConfig.DEBUG) {
            mBinding.tvLogFilePath.setVisibility(View.VISIBLE);
            mBinding.tvLogFilePath.setText(requireContext().getString(R.string.log_file_path, MainApplication.getLogFileDir()));
        }
        mBinding.switchUseAuth.setChecked(mConfigHelper.isUseAuth());
        mBinding.switchMultiDevicesOta.setChecked(mConfigHelper.isSupportMultiDevicesOTA());
    }

    private void saveConfig() {
        boolean isChangeConfig = false;
        boolean isUseAuth = mConfigHelper.isUseAuth();
        boolean isSupportMultiDevicesOTA = mConfigHelper.isSupportMultiDevicesOTA();
        boolean newIsUseAuth = mBinding.switchUseAuth.isChecked();
        boolean newIsSupportMultiDevicesOTA = mBinding.switchMultiDevicesOta.isChecked();
        if (isUseAuth != newIsUseAuth) {
            mConfigHelper.setIsUseAuth(newIsUseAuth);
            isChangeConfig = true;
        }
        if (isSupportMultiDevicesOTA != newIsSupportMultiDevicesOTA) {
            mConfigHelper.setSupportMultiDevicesOTA(newIsSupportMultiDevicesOTA);
            isChangeConfig = true;
        }
        if (isChangeConfig) {
            Toast.makeText(requireContext().getApplicationContext(), requireContext().getString(R.string.modify_config_success), Toast.LENGTH_LONG).show();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    System.exit(0);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, 2000);
        } else {
            Toast.makeText(requireContext().getApplicationContext(), requireContext().getString(R.string.modify_no_change), Toast.LENGTH_LONG).show();
            dismiss();
        }
    }
}
