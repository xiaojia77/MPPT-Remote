package com.jieli.ota.data.model;

import com.jieli.ota.data.constant.OTAConstant;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc  OTA回连状态
 * @since 2022/5/6
 */
public class OTAReconnectState extends OtaState {
    private final ReConnectMsg reconnectMsg;

    public OTAReconnectState(int channel, ReConnectMsg reConnectMsg) {
        super(channel, OTAConstant.STATE_DEVICE_RECONNECT);
        this.reconnectMsg = reConnectMsg;
    }

    public ReConnectMsg getReconnectMsg() {
        return reconnectMsg;
    }

    @Override
    public String toString() {
        return "OTAReconnectState{" +
                "reconnectMsg=" + reconnectMsg +
                "} " + super.toString();
    }
}
