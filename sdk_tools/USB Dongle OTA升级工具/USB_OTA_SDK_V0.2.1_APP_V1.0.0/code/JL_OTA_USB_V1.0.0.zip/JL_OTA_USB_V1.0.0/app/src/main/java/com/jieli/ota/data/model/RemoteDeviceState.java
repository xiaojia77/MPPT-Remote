package com.jieli.ota.data.model;

import androidx.annotation.NonNull;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.jieli.ota.tool.dongle.model.RemoteDevice;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc  远端设备状态
 * @since 2022/5/5
 */
public class RemoteDeviceState implements MultiItemEntity {

    public static final int ITEM_TYPE_DEVICE_NORMAL = 0;
    public static final int ITEM_TYPE_DEVICE_OTA = 1;

    protected final RemoteDevice device;
    private int itemType;
    private int state;
    private int channelColor;
    private boolean isShowOtaFilePath;

    private boolean isSelected;

    private boolean isOTA;
    private int otaType;
    private float progress;
    private ReConnectMsg reconnectMsg;
    private int code;
    private String message;
    private String otaFilePath;
    private int otaTime;

    public RemoteDeviceState(@NonNull RemoteDevice device, int itemType) {
        this.device = device;
        setItemType(itemType);
    }

    @NonNull
    public RemoteDevice getDevice() {
        return device;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getState() {
        return state;
    }

    public int getChannelColor() {
        return channelColor;
    }

    public void setChannelColor(int channelColor) {
        this.channelColor = channelColor;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public boolean isOTA() {
        return isOTA;
    }

    public void setOTA(boolean OTA) {
        isOTA = OTA;
    }

    public int getOtaType() {
        return otaType;
    }

    public void setOtaType(int otaType) {
        this.otaType = otaType;
    }

    public float getProgress() {
        return progress;
    }

    public void setProgress(float progress) {
        this.progress = progress;
    }

    public ReConnectMsg getReconnectMsg() {
        return reconnectMsg;
    }

    public void setReconnectMsg(ReConnectMsg reconnectMsg) {
        this.reconnectMsg = reconnectMsg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isShowOtaFilePath() {
        return isShowOtaFilePath;
    }

    public void setShowOtaFilePath(boolean showOtaFilePath) {
        isShowOtaFilePath = showOtaFilePath;
    }

    public String getOtaFilePath() {
        return otaFilePath;
    }

    public void setOtaFilePath(String otaFilePath) {
        this.otaFilePath = otaFilePath;
    }

    public int getOtaTime() {
        return otaTime;
    }

    public void setOtaTime(int otaTime) {
        this.otaTime = otaTime;
    }

    @Override
    public String toString() {
        return "RemoteDeviceState{" +
                "device=" + device +
                ", itemType=" + itemType +
                ", state=" + state +
                ", channelColor=" + channelColor +
                ", isSelected=" + isSelected +
                ", isOTA=" + isOTA +
                ", otaType=" + otaType +
                ", progress=" + progress +
                ", reconnectMsg=" + reconnectMsg +
                ", code=" + code +
                ", message='" + message + '\'' +
                ", isShowOtaFilePath=" + isShowOtaFilePath +
                ", otaFilePath='" + otaFilePath + '\'' +
                ", otaTime=" + otaTime +
                '}';
    }
}
