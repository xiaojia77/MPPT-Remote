package com.jieli.ota;

import org.junit.Test;

import static org.junit.Assert.*;

import com.jieli.rcsp.util.DataFormatUtil;
import com.jieli.usb.dongle.core.CommandHelper;
import com.jieli.usb.dongle.protocol.CommandPacket;
import com.jieli.usb.dongle.util.DataUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }

    @Test
    public void testCommand_0x02() {
        String dev1Name = "dev1";
        byte[] dev1Data = {0x2, 0x1, 0x2, 0x3, 0x4, 0x05, 0x6, 0x4};
        String dev2Name = "dev2";
        byte[] dev2Data = {0x3, 0x1, 0x2, 0x3, 0x4, 0x05, 0x6, 0x4};

        byte[] cmd2 = {0x4A, 0x4C, 0x10, 0x00, 0x00, 0x03, 0x01, 0x05, 0x01, (byte) 0xED};
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.write(0x4A);
        os.write(0x4C);// head flag
        os.write(0x10);
        os.write(0x00);// channel & ver
        os.write(0x00);
        os.write(0x1a);// param len
        os.write(0x02);// cmd type
        os.write(0x02);// total
        try {
            os.write(dev1Data);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            os.write(dev1Name.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            os.write(dev2Data);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            os.write(dev2Name.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
        os.write(0xed);// end flag

        try {
            os.write(cmd2);
        } catch (IOException e) {
            e.printStackTrace();
        }

        byte[] data = os.toByteArray();
        List<CommandPacket> packetList = CommandHelper.findCommandPacket(data);
        System.out.println("cmd list=" + packetList.size());
        try {
            os.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void testCommand_0x00() {
        byte[] cmd = {0x4A, 0x4C, 0x30, 0x00, 0x00, 0x47, 0x00, (byte) 0xFE, (byte) 0xDC, (byte) 0xBA, 0x00, 0x03, 0x00, 0x3E,
                0x00, 0x00, 0x02, 0x00, 0x20, 0x05, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x4B, 0x72,
                (byte) 0xCF, 0x5B, 0x40, (byte) 0xD8, 0x0E, 0x00, 0x06, 0x04, 0x00, 0x00, 0x00, 0x4E, 0x00, 0x02, 0x05,
                0x00, 0x03, 0x08, 0x00, 0x01, 0x02, 0x09, 0x00, 0x02, 0x0A, 0x00, 0x02, 0x06, 0x01, 0x05,
                0x0D, 0x00, (byte) 0x80, 0x02, 0x1C, 0x08, 0x11, 0x00, 0x4B, 0x72, (byte) 0xCF, 0x4F, 0x4E, (byte) 0xE8, 0x02,
                0x13, 0x00, (byte) 0xEF, (byte) 0xED};
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            os.write(cmd);
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<CommandPacket> packetList = CommandHelper.findCommandPacket(os.toByteArray());
        System.out.println("cmd list=" + packetList.size());
        System.out.println("cmd getChannel=" + packetList.get(0));
    }


    @Test
    public void testCommandParser() {
        byte[] cmd1 = DataFormatUtil.hexStr2Bytes("4A 4C 10 00 00 45 02 03 03 03 A2 4E 84 1A A4 BA 0A 4A 4C 5F 4B 42 28 42 4C 45 29 04 01 30 93 04 A4 26 49 0D 4A 4C 5F 4D 4F 55 53 45 28 42 4C 45 29 02 03 11 22 33 44 55 66 11 55 53 42 5F 55 70");
        byte[] cmd2 = DataFormatUtil.hexStr2Bytes("4A 4C 40 00 00 02 00 FF ED 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00");
        byte[] cmd3 = DataFormatUtil.hexStr2Bytes("64 61 74 65 5F 44 6F 6E 67 6C 65 ED 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00");
        byte[] cmd4 = DataFormatUtil.hexStr2Bytes("4A 4C 40 00 00 12 00 01 38 9B A0 B1 6C D0 7B AE 36 B3 B3 8E 0B 68 5E 20 ED 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00");
        List<byte[]> dataList = new ArrayList<>();
        dataList.add(cmd1);
        dataList.add(cmd2);
        dataList.add(cmd3);
        dataList.add(cmd4);

        for (byte[] cmd : dataList) {
            System.out.println("receive data : " + DataFormatUtil.byte2HexStr(cmd));
            List<CommandPacket> packetList = CommandHelper.findCommandPacket(cmd);
            if(!packetList.isEmpty()){
                for (CommandPacket packet : packetList){
                    System.out.println("packet = " +  packet);
                }
                System.out.println("\n");
            }
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}