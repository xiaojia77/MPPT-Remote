package com.jieli.ota.ui.home;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.snackbar.Snackbar;
import com.jieli.ota.R;
import com.jieli.ota.data.constant.OTAConstant;
import com.jieli.ota.data.model.OTAFinishState;
import com.jieli.ota.data.model.OTAReconnectState;
import com.jieli.ota.data.model.OtaProgressState;
import com.jieli.ota.data.model.RemoteDeviceState;
import com.jieli.ota.databinding.ActivityMainBinding;
import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.ota.ui.adapter.RemoteDeviceAdapter;
import com.jieli.ota.ui.dialog.CommonDialog;
import com.jieli.ota.ui.dialog.ConfigDialog;
import com.jieli.ota.ui.dialog.FileListDialog;
import com.jieli.ota.ui.widget.CommonDecoration;
import com.jieli.ota.util.UIHelper;
import com.jieli.rcsp.util.RcspLog;
import com.jieli.usb.dongle.util.UiHandlerUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 主界面
 */
public class MainActivity extends AppCompatActivity {
    private final String tag = getClass().getSimpleName();
    private ActivityMainBinding binding;
    private MainViewModel viewModel;
    private RemoteDeviceAdapter mAdapter;

    private String selectFilePath = null;
    private boolean isRefreshing = false;//是否刷新中
    private int colorIndex = 0;
    private static final int[] colorArray = new int[]{
            R.drawable.bg_oval_green_shape, R.drawable.bg_oval_blue_shape, R.drawable.bg_oval_orange_shape,
            R.drawable.bg_oval_cyan_shape, R.drawable.bg_oval_yellow_shape, R.drawable.bg_oval_red_shape
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        RcspLog.w(tag, "----------onCreate-----------------");
        UIHelper.setImmersiveStateBar(getWindow(), false);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);
        observeCallback();
        initUI();
        updateUsbState(viewModel.isOpenUsb());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateOTAUI(viewModel.isOTA());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        RcspLog.w(tag, "----------onDestroy-----------------");
        viewModel.release();
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        if (UIHelper.isFastDoubleClick()) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.double_tap_to_exit), Toast.LENGTH_LONG).show();
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private void initUI() {
        String appVersion = UIHelper.getVersionName(getApplicationContext());
        RcspLog.d(tag, "initUI : App Version = " + appVersion);
        binding.viewHomeTopBar.tvLeft.setText(String.format(Locale.getDefault(), "V%s", appVersion));
        binding.viewHomeTopBar.tvLeft.setTextColor(getResources().getColor(R.color.white));
        binding.viewHomeTopBar.tvLeft.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_settings_white, 0, 0, 0);
        binding.viewHomeTopBar.tvLeft.setOnClickListener(v -> {
            ConfigDialog dialog = new ConfigDialog();
            dialog.show(getSupportFragmentManager(), "app_config");
        });
        binding.viewHomeTopBar.tvTitleCenter.setText(UIHelper.getAppName(getApplicationContext()));
        binding.viewHomeTopBar.tvTitleCenter.setTextColor(getResources().getColor(R.color.white));
        binding.viewHomeTopBar.tvRight.setOnClickListener(v -> {
            if (!viewModel.isOpenUsb()) {
                viewModel.openUsbDevice(OTAConstant.USB_VID, OTAConstant.USB_PID);
            } else {
                RcspLog.w(tag, "Usb Device is open.");
                showTips(getString(R.string.usb_device_open_tips, viewModel.getOpenUsbDevice().getDeviceName()));
//                viewModel.closeUsbDevice();
            }
        });
        binding.viewHomeTopBar.getRoot().setBackgroundColor(getResources().getColor(R.color.purple_500));
        binding.srlRemoteDevice.setOnRefreshListener(onRefreshListener);
        binding.groupSelectFile.setVisibility(viewModel.isSupportMultiDevicesOTA() ? View.GONE : View.VISIBLE);
        binding.tvOtaFileMessage.setText(getString(R.string.unselected_file));
        binding.tvOtaFileMessage.setOnClickListener(view -> {
            FileListDialog dialog = new FileListDialog(viewModel.getOtaFileDir(), selectFilePath);
            dialog.setListener((dialog1, file) -> {
                selectFilePath = file.getPath();
                binding.tvOtaFileMessage.setText(String.format(Locale.getDefault(), "%s\t\tsize: %s",
                        file.getName(), UIHelper.getFileSizeDesc(file.length())));
                dialog1.dismiss();
            });
            dialog.show(getSupportFragmentManager(), FileListDialog.class.getSimpleName());
        });
        binding.rvRemoteDevice.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        mAdapter = new RemoteDeviceAdapter();
        mAdapter.setHasStableIds(true);
        mAdapter.setEmptyView(R.layout.view_device_empty);
        mAdapter.setOnItemClickListener((adapter, view, position) -> {
            RemoteDeviceState deviceState = mAdapter.getItem(position);
            if (null == deviceState || deviceState.getItemType() == RemoteDeviceState.ITEM_TYPE_DEVICE_OTA)
                return;
           /* if (deviceState.getDevice().getChannelID() != RemoteDevice.CHANNEL_USB && mAdapter.isUseDeviceSelected()) {
                showTips(getString(R.string.only_usb_device_tips));
                return;
            }
            deviceState.setSelected(!deviceState.isSelected());
            if (deviceState.getDevice().getChannelID() == RemoteDevice.CHANNEL_USB && deviceState.isSelected()) {
                //清空其他远端设备的选择
                boolean isCancelRemoteDeviceSelected = false;
                for (RemoteDeviceState state : mAdapter.getData()) {
                    if (state.getDevice().getChannelID() != RemoteDevice.CHANNEL_USB && state.isSelected()) {
                        state.setSelected(false);
                        isCancelRemoteDeviceSelected = true;
                    }
                }
                if (isCancelRemoteDeviceSelected) {
                    showTips(getString(R.string.cancel_other_remote_device_select));
                }
                mAdapter.notifyDataSetChanged();
                return;
            }*/
            deviceState.setSelected(!deviceState.isSelected());
            mAdapter.notifyItemChanged(position);
        });
        mAdapter.setOnItemChildClickListener((adapter, view, position) -> {
            if (view.getId() == R.id.tv_ota_file_message) {
                RemoteDeviceState deviceState = mAdapter.getItem(position);
                if (null == deviceState || deviceState.getItemType() == RemoteDeviceState.ITEM_TYPE_DEVICE_OTA)
                    return;
                String deviceName = deviceState.getDevice().getDeviceName();
                String otaFilePathDir = viewModel.getOtaFileDir(deviceName);
                FileListDialog dialog = new FileListDialog(deviceState.getDevice().getChannelID(), otaFilePathDir, deviceState.getOtaFilePath());
                dialog.setListener((dialog2, file) -> {
                    RemoteDeviceState remoteDeviceState = mAdapter.getDeviceStateByChannel(dialog2.getChannel());
                    if (remoteDeviceState == null || file == null) return;
                    if (!file.getPath().equals(remoteDeviceState.getOtaFilePath())) {
                        remoteDeviceState.setOtaFilePath(file.getPath());
                        mAdapter.notifyItemChanged(mAdapter.getItemPosition(remoteDeviceState));
                    }
                    dialog2.dismiss();
                });
                dialog.show(getSupportFragmentManager(), FileListDialog.class.getSimpleName());
            }
        });
        binding.rvRemoteDevice.setAdapter(mAdapter);
        RecyclerView.ItemAnimator itemAnimator = binding.rvRemoteDevice.getItemAnimator();
        if (itemAnimator instanceof SimpleItemAnimator) {
            ((SimpleItemAnimator) itemAnimator).setSupportsChangeAnimations(false);
        }
        binding.rvRemoteDevice.addItemDecoration(new CommonDecoration(getApplicationContext(), RecyclerView.VERTICAL,
                getResources().getColor(R.color.transparent), UIHelper.dp2px(getApplicationContext(), 6)));
        binding.btnOta.setOnClickListener(view -> {
            if (viewModel.isOTA()) {
                showTips(getString(R.string.upgrading_tips));
                return;
            }
            List<RemoteDeviceState> deviceStates = mAdapter.getSelectedDevices();
            if (viewModel.isSupportMultiDevicesOTA()) {
                for (RemoteDeviceState state : deviceStates) {
                    String otaFilePath = state.getOtaFilePath();
                    if (otaFilePath == null || otaFilePath.length() == 0) {
                        showTips(getString(R.string.channel_select_ota_file, state.getDevice().getChannelID()));
                        return;
                    }
                }
            } else {
                if (selectFilePath == null || selectFilePath.length() == 0) {
                    showTips(getString(R.string.select_ota_file));
                    return;
                }
                for (RemoteDeviceState state : deviceStates) {
                    state.setOtaFilePath(selectFilePath);
                }
            }
            if (deviceStates.isEmpty()) {
                showTips(getString(R.string.select_ota_device));
                return;
            }
            viewModel.startOTA(deviceStates);
        });
    }

    private void observeCallback() {
        viewModel.usbDeviceStateMLD.observe(this, usbDeviceState -> {
                    if (!usbDeviceState.isOnLine()) {
                        updateUsbState(viewModel.isOpenUsb());
//                        resetRemoteDevices();
                    }
                    colorIndex = 0;
                    showTips(String.format(Locale.getDefault(), "Usb Device[%s] is %s.",
                            usbDeviceState.getDevice().getDeviceName(), usbDeviceState.isOnLine() ? "online" : "offline"));
                }
        );
        viewModel.openUsbResultMLD.observe(this, openUsbResult -> {
            if (openUsbResult.isSuccess()) {
                updateUsbState(true);
                showTips("Open Usb device success. " + openUsbResult.getResult().getDeviceName());
                /*if (viewModel.getDongleInfo() != null && viewModel.getDongleInfo().getEnvStatus() == DongleInfo.ENV_LOADER) {
                    RcspLog.i(tag, "dongle in loader.obtainOnlineDevices ==>");
                    viewModel.obtainOnlineDevices(false);
                }*/
                //不管是否在loader状态，都进行查询在线设备操作
                viewModel.obtainOnlineDevices(false);
            } else {
                updateUsbState(false);
                showTips(String.format(Locale.getDefault(), "Open Usb device have a exception. code = %d, %s",
                        openUsbResult.getCode(), openUsbResult.getMessage()));
            }
        });
        viewModel.onlineDeviceResultMLD.observe(this, onlineDeviceResult -> {
            if (onlineDeviceResult.isSuccess()) {
                updateRemoteDevices(onlineDeviceResult.getResult());
            } else {
                showTips(String.format(Locale.getDefault(), "Obtain Remote Devices have a exception. code = %d, %s",
                        onlineDeviceResult.getCode(), onlineDeviceResult.getMessage()));
            }
        });
        viewModel.isOTAMLD.observe(this, aBoolean -> runOnUiThread(() -> updateOTAUI(aBoolean)));
        viewModel.otaStateMLD.observe(this, otaState -> runOnUiThread(() -> {
            RemoteDeviceState state = mAdapter.getDeviceStateByChannel(otaState.getChannel());
            if (null == state) {
                RcspLog.w(tag, "no found state. " + otaState.getChannel());
                return;
            }
            RcspLog.d(tag, "otaState = " + otaState + ", state = " + state);
            state.setState(otaState.getState());
            state.setItemType(RemoteDeviceState.ITEM_TYPE_DEVICE_OTA);
            state.setOTA(viewModel.isOTA(otaState.getChannel()));
            switch (otaState.getState()) {
                case OTAConstant.STATE_DEVICE_OTA:
                    OtaProgressState progressState = (OtaProgressState) otaState;
                    state.setOtaType(progressState.getOtaType());
                    state.setProgress(progressState.getProgress());
                    state.setOtaTime(progressState.getOtaTime());
                    break;
                case OTAConstant.STATE_DEVICE_RECONNECT:
                    OTAReconnectState reconnectState = (OTAReconnectState) otaState;
                    state.setReconnectMsg(reconnectState.getReconnectMsg());
                    state.setOtaTime(reconnectState.getOtaTime());
                    viewModel.reconnectDevice(otaState.getChannel(), state.getReconnectMsg());
                    break;
                case OTAConstant.STATE_DEVICE_OTA_FINISH:
                    OTAFinishState finishState = (OTAFinishState) otaState;
                    state.setCode(finishState.getCode());
                    state.setMessage(finishState.getMessage());
                    state.setOtaTime(finishState.getOtaTime());
                    String message = getString(R.string.ota_result_tips, finishState.getChannel(),
                            (finishState.getCode() == 0 ? getString(R.string.success) : getString(R.string.failure)),
                            finishState.getCode(),
                            finishState.getMessage()) + "\n" + getString(R.string.ota_use_time)
                            + UIHelper.formatOTATime(finishState.getOtaTime());
                    CommonDialog commonDialog = CommonDialog.builder()
                            .width(0.9f)
                            .cancel(true)
                            .title(getString(R.string.ota_tips))
                            .content(message)
                            .contentGravity(Gravity.CENTER)
                            .left(getString(R.string.sure))
                            .leftClickListener((v, dialogFragment) -> dialogFragment.dismiss())
                            .build();
                    commonDialog.show(getSupportFragmentManager(), "ota_result");
                    break;
            }
            RcspLog.d(tag, "change state = " + state);
            mAdapter.notifyItemChanged(mAdapter.getItemPosition(state));
        }));
    }

    private void resetRemoteDevices() {
        if (isFinishing() || isDestroyed()) return;
        colorIndex = 0;
        updateRemoteDevices(new ArrayList<>());
    }

    @SuppressLint("NotifyDataSetChanged")
    private void updateRemoteDevices(List<RemoteDevice> list) {
        /*if (list.isEmpty()) {
            if (viewModel.isOTA()) {
                RcspLog.w(tag, "updateRemoteDevices : ota is in progress. empty list.");
                return;
            }
            colorIndex = 0;
            mAdapter.setList(new ArrayList<>());
            return;
        }*/
        List<RemoteDeviceState> stateList = new ArrayList<>();
        RcspLog.d(tag, "updateRemoteDevices : cache list = " + mAdapter.getData());
        //优先保留正在OTA的设备
        for (RemoteDeviceState cacheState : mAdapter.getData()) {
            if (cacheState.isOTA()) {
                stateList.add(cacheState);
            }
        }
        RcspLog.d(tag, "updateRemoteDevices : online list = " + list);
        //处理在线设备的状态
        for (RemoteDevice device : list) {
            RemoteDeviceState cacheState = mAdapter.getDeviceStateByChannel(device.getChannelID());
            if (cacheState != null) {
                RcspLog.d(tag, "updateRemoteDevices : cacheState = " + cacheState + ",\ndevice  = " + device);
                if (!cacheState.isOTA()) {
                    if (device.getState() != cacheState.getState()) {
                        cacheState.setState(device.getState());
                        if (cacheState.getItemType() == RemoteDeviceState.ITEM_TYPE_DEVICE_OTA && cacheState.getState() <= OTAConstant.STATE_DEVICE_MANDATORY_UPGRADE) {
                            cacheState.setItemType(RemoteDeviceState.ITEM_TYPE_DEVICE_NORMAL);
                        }
                    }
                    stateList.add(cacheState);
                }
            } else {
                RemoteDeviceState deviceState = new RemoteDeviceState(device, RemoteDeviceState.ITEM_TYPE_DEVICE_NORMAL);
                deviceState.setState(device.getState());
                deviceState.setChannelColor(colorArray[colorIndex]);
                colorIndex = (colorIndex + 1) % colorArray.length;
                deviceState.setShowOtaFilePath(viewModel.isSupportMultiDevicesOTA());
                stateList.add(deviceState);
            }
        }
        RcspLog.d(tag, "updateRemoteDevices : " + stateList);
        mAdapter.setList(stateList);
    }

    private void updateOTAUI(boolean isOTA) {
        binding.btnOta.setText(isOTA ? getString(R.string.ota_in_progress) : getString(R.string.start_ota));
        binding.btnOta.setEnabled(!isOTA);
    }

    private void updateUsbState(boolean isOpen) {
        RcspLog.d(tag, "updateUsbState : " + isOpen);
        binding.viewHomeTopBar.tvRight.setText(isOpen ? getString(R.string.close_usb) : getString(R.string.open_usb));
        binding.viewHomeTopBar.tvRight.setTextColor(getResources().getColor(R.color.white));
        if (!isOpen) resetRemoteDevices();
    }

    private void showTips(String str) {
        RcspLog.i(tag, "showTips : " + str);
        Snackbar.make(binding.getRoot(), str, Snackbar.LENGTH_LONG).show();
    }

    private final SwipeRefreshLayout.OnRefreshListener onRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {
        @Override
        public void onRefresh() {
            if (!isRefreshing) {
                isRefreshing = true;
                viewModel.obtainOnlineDevices(true);
                UiHandlerUtil.postDelayed(() -> {
                    isRefreshing = false;
                    //显示或隐藏刷新进度条
                    binding.srlRemoteDevice.setRefreshing(false);
                }, 1500);
            }
        }
    };
}