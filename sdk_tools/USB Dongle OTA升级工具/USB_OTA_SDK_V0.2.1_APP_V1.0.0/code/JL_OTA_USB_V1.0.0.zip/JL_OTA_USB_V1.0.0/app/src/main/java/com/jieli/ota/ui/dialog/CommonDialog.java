package com.jieli.ota.ui.dialog;


import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.jieli.ota.R;


/**
 * Created by chensenhua on 2018/1/15.
 */

public class CommonDialog extends DialogFragment {
    private final String tag = getClass().getSimpleName();

    private boolean isShow = false;
    private Builder builder;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view;
        if (builder == null && savedInstanceState != null && savedInstanceState.getParcelable("builder") != null) {
            builder = (Builder) savedInstanceState.get("builder");
        }
        if (builder != null && builder.containerRes != 0) {
            view = inflater.inflate(builder.containerRes, container, false);
        } else if (builder != null && builder.containerView != null) {
            view = inflater.inflate(R.layout.dialog_container, container, false);
            ViewGroup linearLayout = view.findViewById(R.id.ll_dialog_container);
            linearLayout.removeAllViews();
            ViewGroup viewGroup = (ViewGroup) builder.containerView.getParent();
            if (viewGroup != null) {
                viewGroup.removeAllViews();
            }
            linearLayout.addView(builder.containerView);
        } else {
            view = inflater.inflate(R.layout.dialog_container, container, false);
            intiDefaultDialog(view);
        }
        requireDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        return view;
    }

    public Builder getBuilder() {
        return builder;
    }

    @Override
    public void onStart() {
        super.onStart();
        Window window = requireDialog().getWindow();
        if (window == null) {
            return;
        }

        WindowManager.LayoutParams mLayoutParams = window.getAttributes();
        mLayoutParams.dimAmount = 0.5f;
        mLayoutParams.flags |= WindowManager.LayoutParams.FLAG_DIM_BEHIND;


        mLayoutParams.width = builder.width < 0 ? WindowManager.LayoutParams.WRAP_CONTENT : (int) (builder.width * getScreenWidth());
        mLayoutParams.height = builder.height < 0 ? WindowManager.LayoutParams.WRAP_CONTENT : (int) (builder.height * getScreenHeight());
/*        mLayoutParams.width =  WindowManager.LayoutParams.WRAP_CONTENT ;
        mLayoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT  ;*/

        window.getDecorView().getRootView().setBackgroundColor(Color.TRANSPARENT);
        window.setAttributes(mLayoutParams);
        setCancelable(builder.cancel);
    }


    private int getScreenWidth() {
        if (getContext() == null) return 0;
        return getContext().getResources().getDisplayMetrics().widthPixels;
    }

    private int getScreenHeight() {
        if (getContext() == null) return 0;
        return getContext().getResources().getDisplayMetrics().heightPixels;
    }

    public boolean isShow() {
        return isShow;
    }

    @Override
    public void onResume() {
        isShow = true;
        super.onResume();
    }

    @Override
    public void show(FragmentManager manager, String tag) {
        isShow = true;
        FragmentTransaction ft = manager.beginTransaction();
        ft.add(this, tag);
        ft.commitAllowingStateLoss();
    }

    @Override
    public void dismiss() {
        isShow = false;
        super.dismissAllowingStateLoss();
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        isShow = false;
        super.onDismiss(dialog);
    }

    @Override
    public void onDestroy() {
        isShow = false;
        super.onDestroy();
    }

    public void intiDefaultDialog(View view) {
        if (builder.backgroundColor != -2) {
            view.findViewById(R.id.ll_dialog_container).setBackgroundColor(builder.backgroundColor);
        }
        initHeader(view);
        initContent(view);
        initBottom(view);
    }

    private void initHeader(View view) {
        if (!TextUtils.isEmpty(builder.title)) {
            TextView tvTitle = view.findViewById(R.id.tv_title);
            tvTitle.setVisibility(View.VISIBLE);
            tvTitle.setText(builder.title);
            if (builder.titleColor != -2) {
                tvTitle.setTextColor(builder.titleColor);
            }
        }
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getDialog().getWindow() == null) return;
        WindowManager.LayoutParams mLayoutParams = getDialog().getWindow().getAttributes();
        if (builder.animations != 0) {
            mLayoutParams.windowAnimations = builder.animations;
        }

    }

    private void initContent(View view) {

        RelativeLayout contentView = null;

        if (builder.contentLayoutView != null || builder.contentLayoutRes != 0) {
            contentView = view.findViewById(R.id.dialog_content_container);
            contentView.setVisibility(View.VISIBLE);
            contentView.removeAllViews();
        }
        if (builder.contentLayoutView != null) {
            ViewGroup viewGroup = (ViewGroup) builder.contentLayoutView.getParent();
            if (viewGroup != null) {
                viewGroup.removeAllViews();
            }
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            params.addRule(RelativeLayout.CENTER_IN_PARENT);
            contentView.addView(builder.contentLayoutView, params);
        } else if (builder.contentLayoutRes != 0) {
            View child = LayoutInflater.from(getContext()).inflate(builder.contentLayoutRes, contentView, false);
            RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) child.getLayoutParams();
            params.addRule(RelativeLayout.CENTER_IN_PARENT);
            view.setLayoutParams(params);
            contentView.addView(child);
        } else if (!TextUtils.isEmpty(builder.content) || builder.showProgressBar) {
            view.findViewById(R.id.content_parent).setVisibility(View.VISIBLE);
            if (!TextUtils.isEmpty(builder.content)) {
                TextView tvContent = view.findViewById(R.id.tv_content);
                tvContent.setVisibility(View.VISIBLE);
                tvContent.setText(builder.content);
                tvContent.setGravity(builder.contentGravity);
                if (builder.contentColor != -2) {
                    tvContent.setTextColor(builder.contentColor);
                }
            }

            ProgressBar progressBar = view.findViewById(R.id.progressBar);
            progressBar.setVisibility(builder.showProgressBar ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putParcelable("builder", builder);
        super.onSaveInstanceState(outState);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }


    private void initBottom(View view) {

        TextView tvLeft = view.findViewById(R.id.tv_left);
        TextView tvRight = view.findViewById(R.id.tv_right);

        if (TextUtils.isEmpty(builder.left) && TextUtils.isEmpty(builder.right)) {
            view.findViewById(R.id.dialog_notify_ll).setVisibility(View.GONE);
            view.findViewById(R.id.line_id).setVisibility(View.GONE);
        } else {
            view.findViewById(R.id.dialog_notify_ll).setVisibility(View.VISIBLE);
            view.findViewById(R.id.line_id).setVisibility(View.VISIBLE);
            if (builder.leftColor != -2) {
                tvLeft.setTextColor(builder.leftColor);
            }
            if (builder.rightColor != -2) {
                tvRight.setTextColor(builder.rightColor);
            }
            if (!TextUtils.isEmpty(builder.left) && TextUtils.isEmpty(builder.right)) {
                tvLeft.setVisibility(View.VISIBLE);
                tvLeft.setText(builder.left);
            } else if (TextUtils.isEmpty(builder.left) && !TextUtils.isEmpty(builder.right)) {
                tvRight.setVisibility(View.VISIBLE);
                tvRight.setText(builder.right);
            } else {
                tvRight.setVisibility(View.VISIBLE);
                tvRight.setText(builder.right);

                view.findViewById(R.id.divider_id).setVisibility(View.VISIBLE);

                tvLeft.setVisibility(View.VISIBLE);
                tvLeft.setText(builder.left);
            }

            tvLeft.setOnClickListener(v -> {
                if (builder.leftClickListener != null) {
                    builder.leftClickListener.onClick(v, CommonDialog.this);
                }
            });
            tvRight.setOnClickListener(v -> {
                if (builder.rightClickListener != null) {
                    builder.rightClickListener.onClick(v, CommonDialog.this);
                }
            });

        }
    }

    public interface OnViewClickListener {
        void onClick(View v, DialogFragment dialogFragment);
    }

    public static Builder builder() {
        return new Builder();
    }


    public static class Builder implements Parcelable {

        private int animations;

        //容器页面
        private int containerRes;
        private View containerView;

        //文字
        private String title;
        private String left;
        private String right;
        private String content;

        //字体颜色
        private int titleColor = -2;
        private int leftColor = -2;
        private int rightColor = -2;
        private int contentColor = -2;

        //位置
        private int contentGravity = Gravity.CENTER;

        //内容布局
        private int contentLayoutRes;
        private View contentLayoutView;

        //背景
        private int backgroundColor = -2;


        private float width = -1; //宽度比0.0~1.0

        private float height = -1; //高度比0.0~1.0

        private boolean cancel = true;

        private boolean showProgressBar = false;


        private OnViewClickListener leftClickListener;


        private OnViewClickListener rightClickListener;

        protected Builder(Parcel in) {
            animations = in.readInt();
            containerRes = in.readInt();
            title = in.readString();
            left = in.readString();
            right = in.readString();
            content = in.readString();
            titleColor = in.readInt();
            leftColor = in.readInt();
            rightColor = in.readInt();
            contentColor = in.readInt();
            contentGravity = in.readInt();
            contentLayoutRes = in.readInt();
            backgroundColor = in.readInt();
            width = in.readFloat();
            height = in.readFloat();
            cancel = in.readByte() != 0;
            showProgressBar = in.readByte() != 0;
        }

        public static final Creator<Builder> CREATOR = new Creator<Builder>() {
            @Override
            public Builder createFromParcel(Parcel in) {
                return new Builder(in);
            }

            @Override
            public Builder[] newArray(int size) {
                return new Builder[size];
            }
        };

        /**
         * 设置高度比：0.0-1.0
         *
         * @param percent
         * @return
         */
        public Builder height(float percent) {
            this.height = percent;
            return this;
        }

        /**
         * 设置宽度比：0.0-1.0
         *
         * @param percent
         * @return
         */
        public Builder width(float percent) {
            this.width = percent;
            return this;
        }

        public Builder animations(int animalRes) {
            this.animations = animalRes;
            return this;
        }


        public Builder cancel(boolean cancel) {
            this.cancel = cancel;
            return this;
        }

        public Builder container(int containerRes) {
            this.containerRes = containerRes;
            return this;
        }

        public Builder containerView(View containerView) {
            this.containerView = containerView;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder content(String content) {
            this.content = content;
            return this;
        }

        public Builder left(String left) {
            this.left = left;
            return this;
        }

        public Builder right(String right) {
            this.right = right;
            return this;
        }

        public Builder titleColor(int color) {
            this.titleColor = color;
            return this;
        }

        public Builder contentColor(int color) {
            this.contentColor = color;
            return this;
        }

        public Builder leftColor(int color) {
            this.leftColor = color;
            return this;
        }

        public Builder rightColor(int color) {
            this.rightColor = color;
            return this;
        }

        public Builder contentGravity(int gravity) {
            this.contentGravity = gravity;
            return this;
        }

        public Builder contentLayoutRes(int contentLayoutRes) {
            this.contentLayoutRes = contentLayoutRes;
            return this;
        }

        public Builder contentLayoutView(View contentLayoutView) {
            this.contentLayoutView = contentLayoutView;
            return this;
        }

        public Builder backgroundColor(int backgroundColor) {
            this.backgroundColor = backgroundColor;
            return this;
        }


        public Builder rightClickListener(OnViewClickListener onClickListener) {
            this.rightClickListener = onClickListener;
            return this;
        }

        public Builder leftClickListener(OnViewClickListener onClickListener) {
            this.leftClickListener = onClickListener;
            return this;
        }

        public Builder showProgressBar(boolean showProgressBar) {
            this.showProgressBar = showProgressBar;
            return this;
        }


        public CommonDialog build() {
            CommonDialog dialog = new CommonDialog();
            dialog.builder = this;
            return dialog;
        }
        public Builder() {

        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(animations);
            dest.writeInt(containerRes);
            dest.writeString(title);
            dest.writeString(left);
            dest.writeString(right);
            dest.writeString(content);
            dest.writeInt(titleColor);
            dest.writeInt(leftColor);
            dest.writeInt(rightColor);
            dest.writeInt(contentColor);
            dest.writeInt(contentGravity);
            dest.writeInt(contentLayoutRes);
            dest.writeInt(backgroundColor);
            dest.writeFloat(width);
            dest.writeFloat(height);
            dest.writeByte((byte) (cancel ? 1 : 0));
            dest.writeByte((byte) (showProgressBar ? 1 : 0));
        }
    }


}
