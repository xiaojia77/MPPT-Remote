package com.jieli.ota.tool.dongle.callback;

import android.hardware.usb.UsbDevice;

import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.usb.dongle.protocol.BaseCommand;

import java.util.List;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc Dongle事件监听器
 * @since 2022/4/29
 */
public abstract class OnDongleEventCallback {

    public void onUsbDeviceState(UsbDevice device, boolean isOnLine){

    }

    public void onRemoteDevicesChange(List<RemoteDevice> list){

    }

    public void onRcspData(int channel, byte[] data){

    }

    public void onDongleCommandNotify(RemoteDevice device, BaseCommand command){

    }

    public void onError(int code, String message){

    }

}
