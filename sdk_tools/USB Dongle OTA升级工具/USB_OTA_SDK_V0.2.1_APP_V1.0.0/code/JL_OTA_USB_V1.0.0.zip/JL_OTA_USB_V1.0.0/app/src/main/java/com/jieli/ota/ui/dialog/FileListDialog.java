package com.jieli.ota.ui.dialog;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.snackbar.Snackbar;
import com.jieli.ota.R;
import com.jieli.ota.databinding.DialogFilesBinding;
import com.jieli.ota.ui.adapter.FileAdapter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 文件列表弹窗
 * @since 2022/5/5
 */
public class FileListDialog extends BaseDialogFragment {
    private final int channel;
    private final String otaFileDirPath;
    private final String selectedFilePath;
    private DialogFilesBinding binding;
    private FileAdapter fileAdapter;
    private OnSelectFileListener listener;

    public FileListDialog(@NonNull String dirPath, @Nullable String selectFilePath) {
        this(0, dirPath, selectFilePath);
    }

    public FileListDialog(int channel, @NonNull String dirPath, @Nullable String selectFilePath) {
        this.channel = channel;
        otaFileDirPath = dirPath;
        this.selectedFilePath = selectFilePath;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        requireDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = requireDialog().getWindow();
        if (window != null) {
            //去掉dialog默认的padding
            window.getDecorView().setPadding(0, 0, 0, 0);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.round(0.9f * getScreenWidth());
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            //设置dialog的动画
//                lp.windowAnimations = R.style.BottomToTopAnim;
            window.setAttributes(lp);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        View root = inflater.inflate(R.layout.dialog_files, container);
        binding = DialogFilesBinding.bind(root);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setCancelable(true);
        fileAdapter = new FileAdapter();
        fileAdapter.setOnItemClickListener((adapter, view1, position) -> {
            File file = fileAdapter.getItem(position);
            if (null == file) return;
            fileAdapter.setSelectedPos(position);
            if (null != listener) listener.onSelected(FileListDialog.this, file);

        });
        binding.rvFilesContent.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvFilesContent.setAdapter(fileAdapter);
        View emptyView = LayoutInflater.from(requireContext()).inflate(R.layout.view_file_empty_tips, null);
        TextView tvEmptyTips = emptyView.findViewById(R.id.tv_empty_tips);
        String tips = String.format(Locale.getDefault(), "%s\n%s", getString(R.string.empty_file_tips), otaFileDirPath);
        tvEmptyTips.setText(tips);
        TextView tvRefresh = emptyView.findViewById(R.id.tv_refresh);
        tvRefresh.setOnClickListener(v -> loadFileListUI(true));
        fileAdapter.setEmptyView(emptyView);
        loadFileListUI(false);
    }

    public void setListener(OnSelectFileListener listener) {
        this.listener = listener;
    }

    public int getChannel() {
        return channel;
    }

    private void readFiles(List<File> fileList, String dirPath) {
        File dir = new File(dirPath);
        File[] files = dir.listFiles();
        if (null != files && files.length > 0) {
            for (File sub : files) {
                if (sub.isDirectory()) {
                    readFiles(fileList, sub.getPath());
                } else if (sub.getName().endsWith(".ufw") || sub.getName().endsWith(".bfu")) {
                    fileList.add(sub);
                }
            }
        }
    }

    private void loadFileListUI(boolean isShowTips) {
        new Thread(() -> {
            final List<File> files = new ArrayList<>();
            readFiles(files, otaFileDirPath);
            requireActivity().runOnUiThread(() -> {
                int selectedIndex = -1;
                for (int index = 0; index < files.size(); index++) {
                    File file = files.get(index);
                    if (null == file) continue;
                    if (file.getPath().equals(selectedFilePath)) {
                        selectedIndex = index;
                        break;
                    }
                }
                if (files.isEmpty() && isShowTips) {
                    Snackbar.make(binding.getRoot(), getString(R.string.not_found_file), Snackbar.LENGTH_LONG).show();
                }
                fileAdapter.setList(files);
                if (selectedIndex != -1) {
                    fileAdapter.setSelectedPos(selectedIndex);
                }
            });
        }).start();
    }

    public interface OnSelectFileListener {

        void onSelected(FileListDialog dialog, File file);
    }
}
