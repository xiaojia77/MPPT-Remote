package com.jieli.ota.ui.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.jieli.ota.R;
import com.jieli.ota.data.constant.OTAConstant;
import com.jieli.ota.data.model.RemoteDeviceState;
import com.jieli.ota.tool.dongle.model.OTADevice;
import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.ota.util.UIHelper;
import com.jieli.rcsp.util.RcspLog;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by zqjasonzhong on 2022/5/4.
 * 远端设备状态适配器
 */
public class RemoteDeviceAdapter extends BaseMultiItemQuickAdapter<RemoteDeviceState, BaseViewHolder> {

    public RemoteDeviceAdapter() {
        addItemType(RemoteDeviceState.ITEM_TYPE_DEVICE_NORMAL, R.layout.item_remote_device_normal);
        addItemType(RemoteDeviceState.ITEM_TYPE_DEVICE_OTA, R.layout.item_remote_device_ota);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder viewHolder, RemoteDeviceState deviceState) {
        if (null == deviceState) return;
        updateChannelUI(viewHolder, deviceState);
        switch (deviceState.getItemType()) {
            case RemoteDeviceState.ITEM_TYPE_DEVICE_NORMAL: {
                boolean isSelect = deviceState.getState() > OTAConstant.STATE_DEVICE_ONLINE && deviceState.isSelected();
                ImageView ivSelect = viewHolder.getView(R.id.iv_choose_flag);
                ivSelect.setVisibility(isSelect ? View.VISIBLE : View.INVISIBLE);
                viewHolder.setVisible(R.id.tv_device_tips, deviceState.getState() == OTAConstant.STATE_DEVICE_MANDATORY_UPGRADE);
                viewHolder.setVisible(R.id.cl_select_ota_file, deviceState.isShowOtaFilePath());
                if (deviceState.isShowOtaFilePath()) {
                    String filePath = deviceState.getOtaFilePath();
                    if (null == filePath) {
                        filePath = getContext().getString(R.string.unselected_file);
                    } else {
                        filePath = UIHelper.getFileName(filePath);
                    }
                    viewHolder.setText(R.id.tv_ota_file_message, filePath);
                    addChildClickViewIds(R.id.tv_ota_file_message);
                    bindViewClickListener(viewHolder, getItemViewType(getItemPosition(deviceState)));
                }
                break;
            }
            case RemoteDeviceState.ITEM_TYPE_DEVICE_OTA: {
                ProgressBar progressBar = viewHolder.getView(R.id.pb_ota_progress);
                String message = null;
                int textColor = R.color.gray_a9a9a9;
                switch (deviceState.getState()) {
                    case OTAConstant.STATE_DEVICE_OTA:
                        int otaType = deviceState.getOtaType();
                        message = otaType == 1 ? getContext().getString(R.string.ota_in_progress) : getContext().getString(R.string.ota_check_file);
                        message += String.format(Locale.getDefault(), "\t%s %.1f %%", getContext().getString(R.string.progress_tips), deviceState.getProgress());
                        progressBar.setProgress(Math.round(deviceState.getProgress()));
                        textColor = R.color.blue_4482DC;
                        break;
                    case OTAConstant.STATE_DEVICE_RECONNECT:
                        progressBar.setProgress(0);
                        if (deviceState.getReconnectMsg() != null) {
                            OTADevice otaDevice = (OTADevice) deviceState.getReconnectMsg().getDevice();
                            message = String.format(Locale.getDefault(), "%s[%s], %s%d", getContext().getString(R.string.ota_ready_reconnect),
                                    otaDevice.getMac(), getContext().getString(R.string.channel_tips), otaDevice.getChannelSeq());
                        } else {
                            message = getContext().getString(R.string.ota_ready_reconnect);
                        }
                        textColor = R.color.green_4CAF50;
                        break;
                    case OTAConstant.STATE_DEVICE_OTA_FINISH:
                        progressBar.setProgress(0);
                        if (deviceState.getCode() == 0) {
                            message = getContext().getString(R.string.ota_success);
                            textColor = R.color.blue_4482DC;
                        } else {
                            message = String.format(Locale.getDefault(), "%s %d,\n%s", getContext().getString(R.string.ota_failed),
                                    deviceState.getCode(), deviceState.getMessage());
                            textColor = R.color.red_D82635;
                        }
                        break;
                }
                if (message != null) {
                    viewHolder.setText(R.id.tv_ota_message, message);
                    viewHolder.setTextColor(R.id.tv_ota_message, getContext().getResources().getColor(textColor));
                }
                viewHolder.setText(R.id.tv_ota_time, String.format(Locale.getDefault(), "%s %s", getContext().getString(R.string.ota_use_time),
                        UIHelper.formatOTATime(deviceState.getOtaTime())));
                break;
            }
        }
    }

    private void updateChannelUI(@NonNull BaseViewHolder viewHolder, @NonNull RemoteDeviceState deviceState){
        RemoteDevice device = deviceState.getDevice();
        TextView tvChannel = viewHolder.getView(R.id.tv_channel);
        tvChannel.setText(String.format(Locale.getDefault(), "CHANNEL\n %s", getChannelDesc(device.getChannelID())));
        /*RcspLog.d("RemoteDeviceAdapter", "convert : " + deviceState
                + ",\n getTag = " + tvChannel.getTag());*/
        if ((!(tvChannel.getTag() instanceof Integer) || ((int)tvChannel.getTag() != deviceState.getChannelColor()))){
//            RcspLog.d("RemoteDeviceAdapter", "setBackgroundResource : " + deviceState.getChannelColor());
            tvChannel.setBackgroundResource(deviceState.getChannelColor());
            tvChannel.setTag(deviceState.getChannelColor());
        }
        viewHolder.setText(R.id.tv_device_name, device.getDeviceName());
        viewHolder.setText(R.id.tv_device_mac, device.getMacDesc());
    }

    public RemoteDeviceState getDeviceStateByChannel(int channel) {
        List<RemoteDeviceState> list = getData();
        if (list.isEmpty()) return null;
        for (RemoteDeviceState state : list) {
            if (channel == state.getDevice().getChannelID()) {
                return state;
            }
        }
        return null;
    }

    public List<RemoteDeviceState> getSelectedDevices() {
        List<RemoteDeviceState> list = getData();
        if (list.isEmpty()) return new ArrayList<>();
        List<RemoteDeviceState> result = new ArrayList<>();
        for (RemoteDeviceState state : list) {
            if (state.isSelected()) {
                result.add(state);
            }
        }
        return result;
    }

    public boolean isUseDeviceSelected() {
        RemoteDeviceState state = getDeviceStateByChannel(RemoteDevice.CHANNEL_USB);
        return state != null && state.isSelected();
    }

    private String getChannelDesc(int channel) {
        if (channel < 10) return "0" + channel;
        return String.valueOf(channel);
    }
}
