package com.jieli.ota.tool.dongle.model;

import androidx.annotation.IntRange;

import com.jieli.rcsp.util.DataFormatUtil;

import java.util.Objects;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 远端设备
 * @since 2022/4/29
 */
public class RemoteDevice {

    public static final int CHANNEL_USB = 2;

    private final int channelID;
    private int state;
    private byte[] mac;
    private String deviceName;
    private boolean isAuthPass;

    public RemoteDevice(@IntRange(from = 0, to = 15) int channelID) {
        this.channelID = channelID;
    }

    public int getChannelID() {
        return channelID;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public byte[] getMac() {
        return mac;
    }

    public void setMac(byte[] mac) {
        this.mac = mac;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public boolean isAuthPass() {
        return isAuthPass;
    }

    public void setAuthPass(boolean authPass) {
        isAuthPass = authPass;
    }

    public String getMacDesc() {
        if (null == mac) return "";
        if (channelID == CHANNEL_USB) {
            return DataFormatUtil.byte2HexStr(mac);
        } else {
            return DataFormatUtil.hexDataCovetToAddress(mac);
        }
    }

    public static byte[] getMacByDesc(int channel, String desc) {
        if (null == desc) return null;
        if (channel == CHANNEL_USB) {
            return DataFormatUtil.hexStr2Bytes(desc);
        } else {
            return DataFormatUtil.addressCovertToByteArray(desc);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RemoteDevice that = (RemoteDevice) o;
        return channelID == that.channelID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(channelID);
    }

    @Override
    public String toString() {
        return "RemoteDevice{" +
                "channelID=" + channelID +
                ", state=" + state +
                ", mac=" + DataFormatUtil.byte2HexStr(mac) +
                ", deviceName='" + deviceName + '\'' +
                ", isAuthPass=" + isAuthPass +
                '}';
    }
}
