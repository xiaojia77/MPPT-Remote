package com.jieli.ota.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jieli.ota.R;
import com.jieli.usb.dongle.protocol.cmd.BluetoothDevicesCmd;

import java.util.Arrays;

/**
 * Des: HID devices
 * author: Bob
 * date: 2022/04/29
 * Copyright: Jieli Technology
 * Modify date:
 * Modified by:
 */
public class DongleAdapter extends ArrayAdapter<BluetoothDevicesCmd.Device> {
    private final int resourceId;

    public DongleAdapter(@NonNull Context context, int resource) {
        super(context, resource);
        this.resourceId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
            viewHolder = new ViewHolder(convertView);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        BluetoothDevicesCmd.Device bean = getItem(position);
        if (bean != null) {
            viewHolder.deviceName.setText(bean.getDeviceName());
            viewHolder.deviceMac.setText(Arrays.toString(bean.getMac()));
        }
        return convertView;
    }

    private static class ViewHolder {
        private final TextView deviceMac;
        private final TextView deviceName;

        ViewHolder(View view) {
            deviceMac = view.findViewById(R.id.tv_device_mac);
            deviceName = view.findViewById(R.id.tv_device_name);

            view.setTag(this);
        }
    }
}
