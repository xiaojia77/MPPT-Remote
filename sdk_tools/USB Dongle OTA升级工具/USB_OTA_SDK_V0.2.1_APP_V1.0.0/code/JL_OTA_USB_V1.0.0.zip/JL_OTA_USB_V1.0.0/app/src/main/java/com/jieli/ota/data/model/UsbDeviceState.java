package com.jieli.ota.data.model;

import android.hardware.usb.UsbDevice;

/**
 * Created by zqjasonzhong on 2022/5/4.
 */

public class UsbDeviceState {
   private final UsbDevice device;
   private final boolean isOnLine;

   public UsbDeviceState(UsbDevice device, boolean isOnLine) {
      this.device = device;
      this.isOnLine = isOnLine;
   }

   public UsbDevice getDevice() {
      return device;
   }

   public boolean isOnLine() {
      return isOnLine;
   }

   @Override
   public String toString() {
      return "UsbDeviceState{" +
              "device=" + device +
              ", isOnLine=" + isOnLine +
              '}';
   }
}
