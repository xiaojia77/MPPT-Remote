package com.jieli.ota.data.model;

import com.jieli.ota.data.constant.OTAConstant;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc  OTA进度状态
 * @since 2022/5/5
 */
public class OtaProgressState extends OtaState {
    private final int otaType;
    private final float progress;

    public OtaProgressState(int channel, int otaType, float progress) {
        super(channel, OTAConstant.STATE_DEVICE_OTA);
        this.otaType = otaType;
        this.progress = progress;
    }

    public int getOtaType() {
        return otaType;
    }

    public float getProgress() {
        return progress;
    }

    @Override
    public String toString() {
        return "OtaProgressState{" +
                "otaType=" + otaType +
                ", progress=" + progress +
                "} " + super.toString();
    }
}
