package com.jieli.ota.demo;

import android.hardware.usb.UsbDevice;

import com.jieli.ota.callback.OnUpgradeCallback;
import com.jieli.ota.data.constant.OTAConstant;
import com.jieli.ota.data.constant.OTAError;
import com.jieli.ota.data.constant.UpgradeType;
import com.jieli.ota.data.model.OTAConfig;
import com.jieli.ota.data.model.ReConnectMsg;
import com.jieli.ota.impl.OTAImpl;
import com.jieli.ota.tool.dongle.DongleManager;
import com.jieli.ota.tool.dongle.callback.OnDongleEventCallback;
import com.jieli.ota.tool.dongle.callback.OnResultListener;
import com.jieli.ota.tool.dongle.model.OTADevice;
import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.ota.tool.ota.bean.OTAOption;
import com.jieli.rcsp.callback.rcsp.OnRcspCallback;
import com.jieli.rcsp.data.constant.Connection;
import com.jieli.rcsp.data.device.Device;
import com.jieli.rcsp.impl.RcspAuth;

import org.junit.Test;

import java.util.List;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OTA初始化示例
 * @since 2022/5/17
 */
public class OTADemo {

    @Test
    public void initOTA(int channel) {
        OTAOption option = new OTAOption(channel); //使用通道
        option.setUseAuthProgress(true);    //是否使用设备认证流程
        option.setDeviceAuthPass(false);    //是否通过设备认证
        final OTAHelper otaHelper = new OTAHelper(option);
        otaHelper.addOnRcspCallback(new OnRcspCallback() {
            @Override
            public void onRcspInit(Device device, boolean isInit) {
                super.onRcspInit(device, isInit);
                //TODO: 判断RCSP库初始化是否成功
                if (isInit) {
                    //操作OTA接口
//                    otaHelper.startOTA();
                }
            }
        });
        otaHelper.isOTA(); //是否正在OTA
        otaHelper.isDeviceConnected(); //是否已连接并初始化RCSP成功
//        otaHelper.isTargetDevice(Device device); //是否目标设备
    }

    @Test
    public void startOTA(int channel, String filePath) {
        OTAOption option = new OTAOption(channel); //使用通道
        option.setUseAuthProgress(true);    //是否使用设备认证流程
        option.setDeviceAuthPass(false);    //是否通过设备认证
        final OTAHelper otaHelper = new OTAHelper(option);
        OTAConfig config = new OTAConfig();
        config.setCommunicationWay(OTAConfig.COMMUNICATION_WAY_BLE);  //通讯方式
        config.setUpdateFilePath(filePath);                           //升级文件存放路径
//        config.setUpdateFileData(fileData);                         //升级文件数据， 如果设置升级数据，优先此方式，两者选其一
        config.setSupportNewRebootWay(false);                         //是否支持新的回连方式, 根据固件程序设置
        otaHelper.startOTA(config, new OnUpgradeCallback() {
            @Override
            public void onStartOTA(Device device) {
                //回调开始OTA
            }

            @Override
            public void onNeedReconnect(Device device, ReConnectMsg reConnectMsg) {
                //回调需要回连设备
            }

            @Override
            public void onProgress(Device device, UpgradeType type, float progress) {
                //回调升级进度
//                UpgradeType.UPGRADE_TYPE_CHECK_FILE    //可能是校验文件，也可能是下载boot loader
//                UpgradeType.UPGRADE_TYPE_FIRMWARE      //升级固件程序
            }

            @Override
            public void onStopOTA(Device device) {
                //回调升级完成 -- 意味着OTA升级成功
            }

            @Override
            public void onCancelOTA(Device device) {
                //回调用户取消OTA
            }

            @Override
            public void onError(Device device, int error, String message) {
                //回调升级过程的异常情况
                //error 参考 OTAError类
            }
        });

        //用户主动取消OTA
        //返回操作结果
        //如果设备是单备份OTA，不允许主动取消OTA，操作无效
        //如果设备是双备份OTA, 则可以主动取消OTA
        boolean ret = otaHelper.cancelOTA();

        otaHelper.isOTA();//是否正在OTA
        //不再使用OTA功能时, 销毁OTA实现类，释放资源
        otaHelper.destroy();
    }

    public static class OTAHelper extends OTAImpl {
        //TODO: 通讯类实现，用户自定义实现，可以是BLE，SPP或者USB等等
        private final DongleManager dongleManager = DongleManager.getInstance();
        //OTA配置选项
        private final OTAOption otaOption; //是否需要设备认证根据固件程序决定, 默认公版是开启设备认证的
        //设备认证处理类
        private final RcspAuth rcspAuth;

        public OTAHelper(OTAOption option) {
            otaOption = option;
            rcspAuth = new RcspAuth(this::sendDataToDevice, new RcspAuth.OnRcspAuthListener() {
                @Override
                public void onInitResult(boolean result) {

                }

                @Override
                public void onAuthSuccess(Device device) {
                    otaOption.setDeviceAuthPass(true);
                    //TODO: 回传设备上线
                    transmitDeviceStatus(device, Connection.CONNECTION_CONNECTED);
                }

                @Override
                public void onAuthFailed(Device device, int code, String message) {
                    //TODO: 回传设备下线
                    callbackDeviceConnectFailed(device);
                }
            });
            dongleManager.addOnDongleEventCallback(mOnDongleEventCallback);
        }

        @Override
        public boolean sendDataToDevice(Device device, byte[] data) {
            //TODO: 用户必须实现数据发送
            //可以是阻塞方法，也可以是异步函数处理
            RemoteDevice remoteDevice = dongleManager.findRemoteDeviceByChannel(otaOption.getChannel());
            if (null == remoteDevice) return false;
            dongleManager.sendRcspData(remoteDevice, data, new OnResultListener<Boolean>() {
                @Override
                public void onResult(Boolean result) {

                }

                @Override
                public void onFailed(int code, String message) {

                }
            });
            return true;
        }

        @Override
        public void destroy() {
            super.destroy();
            rcspAuth.destroy();
            dongleManager.removeOnDongleEventCallback(mOnDongleEventCallback);
        }

        public boolean isDeviceAuthPass() {
            if (!otaOption.isUseAuthProgress()) return true;
            return otaOption.isDeviceAuthPass();
        }

        private void callbackDeviceConnectFailed(Device device) {
            otaOption.setDeviceAuthPass(false);
            transmitDeviceStatus(device, Connection.CONNECTION_DISCONNECT);
        }

        private final OnDongleEventCallback mOnDongleEventCallback = new OnDongleEventCallback() {
            @Override
            public void onUsbDeviceState(UsbDevice device, boolean isOnLine) {
                super.onUsbDeviceState(device, isOnLine);
                if (!isOnLine && getUsingDevice() != null) {
                    //TODO: 回传设备下线
                    callbackDeviceConnectFailed(getUsingDevice());
                }
            }

            @Override
            public void onRemoteDevicesChange(List<RemoteDevice> list) {
                super.onRemoteDevicesChange(list);
                //TODO: 回传设备下线
                if (list.isEmpty() && getUsingDevice() != null) {
                    callbackDeviceConnectFailed(getUsingDevice());
                    return;
                }
                RemoteDevice device = null;
                for (RemoteDevice remoteDevice : list) {
                    if (remoteDevice.getChannelID() == otaOption.getChannel()) {
                        device = remoteDevice;
                        break;
                    }
                }
                if (null == device) return;
                OTADevice otaDevice = OTADevice.changeOTADevice(device);
                if (device.getState() == OTAConstant.STATE_DEVICE_OFFLINE) {
                    //TODO: 回传设备下线
                    callbackDeviceConnectFailed(otaDevice);
                } else if (device.getState() == OTAConstant.STATE_DEVICE_ONLINE) {
                    if (isDeviceAuthPass()) { //设备已通过认证
                        //TODO: 回传设备上线
                        transmitDeviceStatus(otaDevice, Connection.CONNECTION_CONNECTED);
                    } else { //设备未通过认证
                        rcspAuth.stopAuth(otaDevice, false);
                        if (!rcspAuth.startAuth(otaDevice)) {
                            //TODO: 回传设备下线
                            callbackDeviceConnectFailed(otaDevice);
                        }
                    }
                }
            }

            @Override
            public void onRcspData(int channel, byte[] data) {
                super.onRcspData(channel, data);
                if (channel != otaOption.getChannel() || (null == data || data.length == 0)) return;
                //TODO: 回传接收到的设备数据
                if (getUsingDevice() != null) {
                    if (isDeviceAuthPass()) {  //设备已通过认证
                        transmitDeviceData(getUsingDevice(), data);
                    } else { //设备未通过认证
                        rcspAuth.handleAuthData(getUsingDevice(), data);
                    }
                }
            }
        };
    }
}
