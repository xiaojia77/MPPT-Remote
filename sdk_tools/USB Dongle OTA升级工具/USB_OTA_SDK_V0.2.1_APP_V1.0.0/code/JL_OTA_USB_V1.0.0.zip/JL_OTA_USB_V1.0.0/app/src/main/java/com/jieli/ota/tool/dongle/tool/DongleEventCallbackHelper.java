package com.jieli.ota.tool.dongle.tool;

import android.hardware.usb.UsbDevice;
import android.os.Handler;
import android.os.Looper;

import com.jieli.ota.tool.dongle.callback.OnDongleEventCallback;
import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.usb.dongle.protocol.BaseCommand;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc Dongle事件回调处理类
 * @since 2022/4/29
 */
public class DongleEventCallbackHelper extends OnDongleEventCallback {
    private final ArrayList<OnDongleEventCallback> callbacks = new ArrayList<>();
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    public void addOnDongleEventCallback(OnDongleEventCallback callback) {
        if (null == callback || callbacks.contains(callback)) return;
        callbacks.add(callback);
    }

    public void removeOnDongleEventCallback(OnDongleEventCallback callback) {
        if (null == callback || callbacks.isEmpty()) return;
        callbacks.remove(callback);
    }

    public void release(){
        callbacks.clear();
        mHandler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onUsbDeviceState(UsbDevice device, boolean isOnLine) {
        callbackEvent(callback -> callback.onUsbDeviceState(device, isOnLine));
    }

    @Override
    public void onRemoteDevicesChange(List<RemoteDevice> list) {
        callbackEvent(callback -> callback.onRemoteDevicesChange(list));
    }

    @Override
    public void onRcspData(int channel, byte[] data) {
        callbackEvent(callback -> callback.onRcspData(channel, data));
    }

    @Override
    public void onDongleCommandNotify(RemoteDevice device, BaseCommand command) {
        callbackEvent(callback -> callback.onDongleCommandNotify(device, command));
    }

    @Override
    public void onError(int code, String message) {
        callbackEvent(callback -> callback.onError(code, message));
    }

    private void callbackEvent(IHandle handle) {
        if (null == handle) return;
        Runnable runnable = new CallbackRunnable(handle);
        if (Thread.currentThread().getId() == Looper.getMainLooper().getThread().getId()) {
            runnable.run();
        } else {
            mHandler.post(runnable);
        }
    }

    private interface IHandle {

        void onHandle(OnDongleEventCallback callback);
    }

    private class CallbackRunnable implements Runnable {
        private final IHandle handle;

        public CallbackRunnable(IHandle handle) {
            this.handle = handle;
        }

        @Override
        public void run() {
            if (null == handle || callbacks.isEmpty()) return;
            for (OnDongleEventCallback callback : new ArrayList<>(callbacks)) {
                handle.onHandle(callback);
            }
        }
    }
}
