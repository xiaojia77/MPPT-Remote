package com.jieli.ota.tool.dongle.model;

/**
 * Created by zqjasonzhong on 2022/4/30.
 */
public class DongleInfo {
   public static final int ENV_SDK = 0;
   public static final int ENV_LOADER = 1;

   private int sdkFlag;
   private int usbVid;
   private int usbPid;
   private int usbVersion;
   private int envStatus;

   public int getSdkFlag() {
      return sdkFlag;
   }

   public DongleInfo setSdkFlag(int sdkFlag) {
      this.sdkFlag = sdkFlag;
      return this;
   }

   public int getUsbVid() {
      return usbVid;
   }

   public DongleInfo setUsbVid(int usbVid) {
      this.usbVid = usbVid;
      return this;
   }

   public int getUsbPid() {
      return usbPid;
   }

   public DongleInfo setUsbPid(int usbPid) {
      this.usbPid = usbPid;
      return this;
   }

   public int getUsbVersion() {
      return usbVersion;
   }

   public DongleInfo setUsbVersion(int usbVersion) {
      this.usbVersion = usbVersion;
      return this;
   }

   public int getEnvStatus() {
      return envStatus;
   }

   public DongleInfo setEnvStatus(int envStatus) {
      this.envStatus = envStatus;
      return this;
   }

   @Override
   public String toString() {
      return "DongleInfo{" +
              "sdkFlag=" + sdkFlag +
              ", usbVid=" + usbVid +
              ", usbPid=" + usbPid +
              ", usbVersion=" + usbVersion +
              ", envStatus=" + envStatus +
              '}';
   }
}
