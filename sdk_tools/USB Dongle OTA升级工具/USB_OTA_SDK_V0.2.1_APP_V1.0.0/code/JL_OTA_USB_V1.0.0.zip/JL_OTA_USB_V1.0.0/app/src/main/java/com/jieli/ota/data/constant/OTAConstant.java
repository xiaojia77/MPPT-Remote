package com.jieli.ota.data.constant;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OTA常量定义
 * @since 2022/5/5
 */
public class OTAConstant {

    //dir name
    public static final String DIR_LOGCAT = "logcat";
    public static final String DIR_UPGRADE = "upgrade";
    public static final String DIR_MOUSE = "mouse";
    public static final String DIR_KB = "kb";
    public static final String DIR_DONGLE = "dongle";

    //device name prefix
    public static final String PREFIX_MOUSE = "JL_MOUSE";
    public static final String PREFIX_KEYBOARD = "JL_KB";
    public static final String PREFIX_DONGLE = "USB_Update_Dongle";

    public static final String OTA_FILE_SUFFIX = ".ufw";

    //USB message
    public static final int USB_VID = 0x4c4a;
    public static final int USB_PID = 0x4155;

    //Device state
    public static final int STATE_DEVICE_OFFLINE = 0;
    public static final int STATE_DEVICE_ONLINE = 1;
    public static final int STATE_DEVICE_INIT_RCSP = 2;
    public static final int STATE_DEVICE_MANDATORY_UPGRADE = 3;
    public static final int STATE_DEVICE_OTA = 4;
    public static final int STATE_DEVICE_RECONNECT = 5;
    public static final int STATE_DEVICE_OTA_FINISH = 6;


    //config
    public static final boolean IS_USE_AUTH = true;        //是否使用设备认证
    public static final boolean MULTI_DEVICES_OTA = true;  //是否多设备升级
    public static final boolean IS_AUTO_OTA_TEST = false;  //是否自动OTA测试
    public static final int AUTO_OTA_COUNT = 30;           //默认自动化OTA次数
}
