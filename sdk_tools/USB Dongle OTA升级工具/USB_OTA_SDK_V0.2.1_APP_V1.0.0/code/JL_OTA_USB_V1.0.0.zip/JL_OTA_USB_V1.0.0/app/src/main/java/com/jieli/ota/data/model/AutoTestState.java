package com.jieli.ota.data.model;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 自动化测试状态
 * @since 2022/10/12
 */
public class AutoTestState {
    public static final int STATE_IDLE = 0;
    public static final int STATE_START = 1;
    public static final int STATE_TEST_COUNT = 2;

    private int state = STATE_IDLE;
    private int count;
    private int total;
    private int code;
    private String message;

    public int getState() {
        return state;
    }

    public AutoTestState setState(int state) {
        this.state = state;
        return this;
    }

    public int getCount() {
        return count;
    }

    public AutoTestState setCount(int count) {
        this.count = count;
        return this;
    }

    public int getTotal() {
        return total;
    }

    public AutoTestState setTotal(int total) {
        this.total = total;
        return this;
    }

    public int getCode() {
        return code;
    }

    public AutoTestState setCode(int code) {
        this.code = code;
        return this;
    }

    public String getMessage() {
        return message;
    }

    public AutoTestState setMessage(String message) {
        this.message = message;
        return this;
    }

    @Override
    public String toString() {
        return "AutoTestState{" +
                "state=" + state +
                ", count=" + count +
                ", total=" + total +
                ", code=" + code +
                ", message='" + message + '\'' +
                '}';
    }
}
