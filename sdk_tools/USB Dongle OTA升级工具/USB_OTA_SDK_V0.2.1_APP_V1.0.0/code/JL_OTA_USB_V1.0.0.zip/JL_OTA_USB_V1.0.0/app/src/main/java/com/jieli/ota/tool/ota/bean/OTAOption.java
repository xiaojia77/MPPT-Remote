package com.jieli.ota.tool.ota.bean;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OTA配置项
 * @since 2022/5/7
 */
public class OTAOption {
    private int channel;                //通道号
    private boolean isUseAuthProgress;        //是否开启设备认证
    private boolean isDeviceAuthPass;         //是否通过设备认证

    public OTAOption(int channel) {
        this.channel = channel;
    }

    public int getChannel() {
        return channel;
    }

    public void setChannel(int channel) {
        this.channel = channel;
    }

    public boolean isUseAuthProgress() {
        return isUseAuthProgress;
    }

    public OTAOption setUseAuthProgress(boolean useAuthProgress) {
        isUseAuthProgress = useAuthProgress;
        return this;
    }

    public boolean isDeviceAuthPass() {
        return isDeviceAuthPass;
    }

    public OTAOption setDeviceAuthPass(boolean deviceAuthPass) {
        isDeviceAuthPass = deviceAuthPass;
        return this;
    }

    @Override
    public String toString() {
        return "OTAOption{" +
                "channel=" + channel +
                ", isUseAuthProgress=" + isUseAuthProgress +
                ", isDeviceAuthPass=" + isDeviceAuthPass +
                '}';
    }
}
