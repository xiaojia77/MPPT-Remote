package com.jieli.ota;

import android.app.Application;
import android.content.Context;

import com.jieli.ota.data.constant.OTAConstant;
import com.jieli.ota.util.CrashHandler;
import com.jieli.ota.util.SaveLogTask;
import com.jieli.ota.util.UIHelper;
import com.jieli.rcsp.util.RcspLog;
import com.jieli.usb.dongle.util.Jlog;

public class MainApplication extends Application {
    private static MainApplication application;

    private static String logFileDir;
    private SaveLogTask mSaveLogTask;


    @Override
    public void onCreate() {
        super.onCreate();
        application = this;

        CrashHandler.getInstance().init(application);
        boolean isDebug = BuildConfig.DEBUG;
        RcspLog.setIsLog(isDebug);
        Jlog.openOrCloseDebug(isDebug);
        if (isDebug) {
            logFileDir = UIHelper.createFilePath(getApplicationContext(), OTAConstant.DIR_LOGCAT);
            mSaveLogTask = new SaveLogTask(logFileDir);
            mSaveLogTask.start();
            RcspLog.setLogOutput(logcat -> mSaveLogTask.addLogMessage(logcat));
            Jlog.setLogOutput(logcat -> mSaveLogTask.addLogMessage(logcat));
        }
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        if (null != mSaveLogTask && mSaveLogTask.isRunning()) {
            mSaveLogTask.stopRunning();
            mSaveLogTask = null;
        }
        RcspLog.setIsLog(false);
        Jlog.openOrCloseDebug(false);
    }

    public static Context getContext() {
        return application;
    }

    public static String getLogFileDir() {
        return logFileDir;
    }
}
