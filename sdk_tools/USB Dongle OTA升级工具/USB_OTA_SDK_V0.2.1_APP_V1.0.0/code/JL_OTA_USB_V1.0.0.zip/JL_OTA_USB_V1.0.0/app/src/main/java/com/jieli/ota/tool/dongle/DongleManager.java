package com.jieli.ota.tool.dongle;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.jieli.ota.MainApplication;
import com.jieli.ota.R;
import com.jieli.ota.data.constant.OTAConstant;
import com.jieli.ota.tool.config.ConfigHelper;
import com.jieli.ota.tool.dongle.callback.IDongleOp;
import com.jieli.ota.tool.dongle.callback.OnDongleEventCallback;
import com.jieli.ota.tool.dongle.callback.OnResultListener;
import com.jieli.ota.tool.dongle.model.DongleInfo;
import com.jieli.ota.tool.dongle.model.OTADevice;
import com.jieli.ota.tool.dongle.model.OpenUsbParam;
import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.ota.tool.dongle.tool.DongleEventCallbackHelper;
import com.jieli.ota.tool.dongle.util.DongleError;
import com.jieli.ota.tool.dongle.util.DongleUtil;
import com.jieli.ota.tool.ota.OTAManager;
import com.jieli.ota.tool.ota.bean.OTAOption;
import com.jieli.rcsp.callback.rcsp.OnRcspCallback;
import com.jieli.rcsp.data.constant.Connection;
import com.jieli.rcsp.data.device.Device;
import com.jieli.rcsp.util.DataFormatUtil;
import com.jieli.rcsp.util.RcspLog;
import com.jieli.usb.dongle.UsbClientImpl;
import com.jieli.usb.dongle.callback.CommandCallback;
import com.jieli.usb.dongle.callback.UsbCallback;
import com.jieli.usb.dongle.listener.OnDongleEventListener;
import com.jieli.usb.dongle.model.ErrorCode;
import com.jieli.usb.dongle.protocol.BaseCommand;
import com.jieli.usb.dongle.protocol.Command;
import com.jieli.usb.dongle.protocol.cmd.BluetoothDevicesCmd;
import com.jieli.usb.dongle.protocol.cmd.BluetoothStateCmd;
import com.jieli.usb.dongle.protocol.cmd.ConnectRemoteCmd;
import com.jieli.usb.dongle.protocol.cmd.DeviceAuthFlagCmd;
import com.jieli.usb.dongle.protocol.cmd.DisconnectRemoteCmd;
import com.jieli.usb.dongle.protocol.cmd.DongleInfoCmd;
import com.jieli.usb.dongle.protocol.cmd.RcspCmd;
import com.jieli.usb.dongle.util.Const;
import com.jieli.usb.dongle.util.Jlog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public class DongleManager extends UsbClientImpl implements IDongleOp {
    public static final String ACTION_USB_PERMISSION = "com.jieli.action.USB_PERMISSION";
    @SuppressLint("StaticFieldLeak")
    private static volatile DongleManager instance;
    private final String tag = getClass().getSimpleName();
    private final UsbManager usbManager;
    private final DongleEventCallbackHelper mCallbackHelper;
    private final ConfigHelper mConfigHelper = ConfigHelper.getInstance();

    private volatile OpenUsbDeviceTask mOpenUsbDeviceTask;
    private volatile UsbReceiver mUsbReceiver;
    private volatile UsbDevice mUsbDevice;
    private volatile OpenUsbParam mOpenUsbParam;
    private volatile OTAManager dongleOTAManager;   //本地升级OTA管理器
    private volatile DongleInfo mDongleInfo;        //缓存的Dongle信息
    private final Map<Integer, OTAManager> otaManagerMap = Collections.synchronizedMap(new HashMap<>());
    private final List<RemoteDevice> deviceList = Collections.synchronizedList(new ArrayList<>());

    public static DongleManager getInstance() {
        if (null == instance) {
            synchronized (DongleManager.class) {
                if (null == instance) {
                    instance = new DongleManager();
                }
            }
        }
        return instance;
    }

    private DongleManager() {
        super(MainApplication.getContext());
        usbManager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (usbManager == null) {
            throw new NullPointerException("No Usb service");
        }
        mCallbackHelper = new DongleEventCallbackHelper();
        registerUsbReceiver();
    }

    @Override
    public UsbDevice getOpenUsbDevice() {
        return mUsbDevice;
    }

    @Override
    public DongleInfo getDongleInfo() {
        return mDongleInfo;
    }

    @Override
    public void addOnDongleEventCallback(OnDongleEventCallback callback) {
        mCallbackHelper.addOnDongleEventCallback(callback);
    }

    @Override
    public void removeOnDongleEventCallback(OnDongleEventCallback callback) {
        mCallbackHelper.removeOnDongleEventCallback(callback);
    }

    @Override
    public void openUsbDevice(int vid, int pid, OnResultListener<UsbDevice> listener) {
        Jlog.d(tag, "openUsbDevice : vid = " + vid + ", pid = " + pid);
        UsbDevice usbDevice = findDevice(vid, pid);
        if (null == usbDevice) {
            vid = vid + 256; //因为windows 7的兼容性, dongle的loader修改了VID
            Jlog.d(tag, "openUsbDevice : change after, vid = " + vid + ", pid = " + pid);
            usbDevice = findDevice(vid, pid);  //重新获取USBDevice
        }
        if(null == usbDevice){
            if (listener != null)
                listener.onFailed(DongleError.ERR_NOT_FOUNT_DEVICE, "Not found usb device.");
            return;
        }
        if (!usbManager.hasPermission(usbDevice)) {
            Jlog.w(tag, "Request permission now");
            setOpenUsbParam(new OpenUsbParam(vid, pid, listener));
            int flag = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) {
                flag = PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent permissionIntent = PendingIntent.getBroadcast(context, 0, new Intent(ACTION_USB_PERMISSION), flag);
            usbManager.requestPermission(usbDevice, permissionIntent);
        } else {
            Jlog.i(tag, "Have permission now");
            tryToOpenUsbDevice(usbDevice, listener);
        }
    }

    @Override
    public void closeUseDevice(UsbDevice device) {
        if (null != device && !device.equals(getOpenUsbDevice())) {
            mCallbackHelper.onError(DongleError.ERR_INVALID_PARAM, "Invalid param");
            return;
        }
        close();
        if (!otaManagerMap.isEmpty()) {
            for (OTAManager manager : otaManagerMap.values()) {
                manager.destroy();
            }
            otaManagerMap.clear();
        }
        RemoteDevice dongleDevice = null;
        if (dongleOTAManager != null) {
            if (dongleOTAManager.isOTA()) {//Dongle重启, 缓存设备信息
                RemoteDevice remoteDevice = findRemoteDeviceByChannel(dongleOTAManager.getChannelSeq());
                dongleDevice = new RemoteDevice(dongleOTAManager.getChannelSeq());
                if (remoteDevice != null) {
                    dongleDevice.setDeviceName(remoteDevice.getDeviceName());
                    dongleDevice.setMac(remoteDevice.getMac());
                } else {
                    dongleDevice.setDeviceName("dongle_OTA");
                    dongleDevice.setMac(DataFormatUtil.addressCovertToByteArray("11:22:33:44:55:66"));
                }
                dongleDevice.setState(OTAConstant.STATE_DEVICE_OFFLINE);
                dongleDevice.setAuthPass(false);
            } else {
                dongleOTAManager.destroy();
                dongleOTAManager = null;
            }
        }
        deviceList.clear();
        if (dongleDevice != null) { //重新添加缓存信息
            deviceList.add(dongleDevice);
        }
        setDongleInfo(null);
        setUsbDevice(null);
    }

    @Override
    public void sendRcspData(RemoteDevice device, byte[] data, OnResultListener<Boolean> listener) {
        RcspCmd cmd = new RcspCmd();
        cmd.setRcspData(data);
        cmd.setChannel(device.getChannelID());
        send(cmd, new BooleanCommandCallback(listener));
    }

    @Override
    public void getDongleInfo(OnResultListener<DongleInfo> listener) {
        send(new DongleInfoCmd(), new CommandCallback() {
            @Override
            public void onSent(BaseCommand command) {

            }

            @Override
            public void onError(ErrorCode code) {
                if (null != listener) listener.onFailed(code.code, code.message);
            }

            @Override
            public void onResponse(BaseCommand command) {
                super.onResponse(command);
                DongleInfoCmd dongleInfoCmd = (DongleInfoCmd) command;
                DongleInfo dongleInfo = new DongleInfo()
                        .setSdkFlag(dongleInfoCmd.getSdkVersion())
                        .setUsbVid(dongleInfoCmd.getVid())
                        .setUsbPid(dongleInfoCmd.getPid())
                        .setUsbVersion(dongleInfoCmd.getVersion())
                        .setEnvStatus(dongleInfoCmd.getEnvStatus());
                if (null != listener) listener.onResult(dongleInfo);
            }
        });
    }

    @Override
    public void obtainOnLineDevices(OnResultListener<Boolean> listener) {
        send(new BluetoothDevicesCmd(), new CommandCallback() {

            @Override
            public void onSent(BaseCommand command) {
                Jlog.d(tag, "onSent:" + command + ", thread : " + Thread.currentThread());
                if (null != listener) listener.onResult(true);
            }

            @Override
            public void onError(ErrorCode code) {
                Jlog.e(tag, "onError:" + code);
                if (null != listener) listener.onFailed(code.code, code.message);
            }

            @Override
            public void onResponse(BaseCommand command) {
                Jlog.e(tag, "onResponse=" + command + ", thread : " + Thread.currentThread());
                BluetoothDevicesCmd cmd = (BluetoothDevicesCmd) command;
                handleOnlineDevices(cmd.getBluetoothDevices());
            }
        });
    }

    @Override
    public void connectRemoteDevice(RemoteDevice device, OnResultListener<Boolean> listener) {
        ConnectRemoteCmd cmd = new ConnectRemoteCmd();
        cmd.setRemoteChannel(device.getChannelID());
        cmd.setMac(device.getMac());
        cmd.setUseNewConnectWay(false);
        send(cmd, new BooleanCommandCallback(listener));
    }

    @Override
    public void disconnectRemoteDevice(int channel, OnResultListener<Boolean> listener) {
        DisconnectRemoteCmd cmd = new DisconnectRemoteCmd();
        cmd.setRemoteChannel(channel);
        send(cmd, new BooleanCommandCallback(listener));
    }

    @Override
    public void setChannelAuthFlag(int channel, boolean isAuthPass, OnResultListener<Boolean> listener) {
        DeviceAuthFlagCmd cmd = new DeviceAuthFlagCmd();
        cmd.setAuthed(isAuthPass);
        cmd.setDeviceChannel(channel);
        send(cmd, new BooleanCommandCallback(listener));
    }

    public UsbDevice findDevice(int vid, int pid) {
        Map<String, UsbDevice> devices = usbManager.getDeviceList();
        for (UsbDevice device : devices.values()) {
            if ((vid == 0 || device.getVendorId() == vid) && (pid == 0 || device.getProductId() == pid)) {
                for (int i = 0; i < device.getInterfaceCount(); i++) {
                    UsbInterface usbInterface = device.getInterface(i);
                    if (usbInterface.getInterfaceClass() == Const.INTERFACE_CLASS_HID) {
                        return device;
                    }
                }
            }
        }
        return null;
    }

    public OTAManager getOtaManager(int channel) {
        if (channel < 2 || channel > 15) return null;
        if (channel == RemoteDevice.CHANNEL_USB) return dongleOTAManager;
        return otaManagerMap.get(channel);
    }

    public void release() {
        unregisterUsbReceiver();
        closeOpenUsvDevice();
        closeUseDevice(getOpenUsbDevice());
        if (dongleOTAManager != null) { //强制销毁
            dongleOTAManager.destroy();
            dongleOTAManager = null;
        }
        mCallbackHelper.release();
        mConfigHelper.release();
        instance = null;
    }

    public RemoteDevice findRemoteDeviceByChannel(int channel) {
        return findRemoteDeviceByChannel(deviceList, channel);
    }

    public RemoteDevice findRemoteDeviceByOTADevice(OTADevice device) {
        if (null == device) return null;
        return findRemoteDeviceByChannel(device.getChannelSeq());
    }

    private void setUsbDevice(UsbDevice usbDevice) {
        mUsbDevice = usbDevice;
    }

    private void setOpenUsbParam(OpenUsbParam openUsbParam) {
        Jlog.d(tag, "setOpenUsbParam : " + openUsbParam);
        mOpenUsbParam = openUsbParam;
    }

    private void setDongleInfo(DongleInfo dongleInfo) {
        mDongleInfo = dongleInfo;
    }

    private boolean removeOtaManager(int channel) {
        OTAManager otaManager = getOtaManager(channel);
        Jlog.w(tag, "removeOtaManager : channel = " + channel);
        if (null != otaManager && !otaManager.isOTA()) {
            OTADevice otaDevice = OTADevice.changeOTADevice(findRemoteDeviceByChannel(channel));
            Jlog.w(tag, "removeOtaManager : " + otaDevice + ", not in ota. destroy");
            otaManager.transmitDeviceStatus(otaDevice, Connection.CONNECTION_DISCONNECT);
            otaManager.destroy();
            return otaManagerMap.remove(channel) != null;
        }
        return false;
    }

    private RemoteDevice findRemoteDeviceByChannel(@NonNull List<RemoteDevice> list, int channel) {
        if (channel < 2 || channel > 15 || list.isEmpty()) return null;
        for (RemoteDevice remoteDevice : list) {
            if (remoteDevice.getChannelID() == channel) {
                return remoteDevice;
            }
        }
        return null;
    }

    private void tryToOpenUsbDevice(UsbDevice device, OnResultListener<UsbDevice> listener) {
        if (null == mOpenUsbDeviceTask) {
            mOpenUsbDeviceTask = new OpenUsbDeviceTask(device, listener);
            mOpenUsbDeviceTask.start();
        } else {
            Jlog.i(tag, "tryToOpenUsbDevice : Opening usb ===>");
            if (null != listener)
                listener.onFailed(DongleError.ERR_IN_PROGRESS, "Opening usb device!");
        }
    }

    private void closeOpenUsvDevice() {
        if (null != mOpenUsbDeviceTask) {
            mOpenUsbDeviceTask.interrupt();
            mOpenUsbDeviceTask = null;
        }
    }

    private void handleOnlineDevices(List<BluetoothDevicesCmd.Device> list) {
        List<RemoteDevice> remoteDevices = DongleUtil.convertToRemoteDeviceList(list); //新的在线设备数据
        for (RemoteDevice remoteDevice : remoteDevices) {
            int channel = remoteDevice.getChannelID();
            OTAManager otaManager = getOtaManager(channel);
            if (otaManager != null && otaManager.isDeviceConnected()) { //认证已过
                remoteDevice.setState(OTAConstant.STATE_DEVICE_INIT_RCSP);
            }
            RemoteDevice cacheDevice = findRemoteDeviceByChannel(deviceList, channel);
            RcspLog.d(tag, "handleOnlineDevices : remoteDevice = " + remoteDevice + ",\n" + "cacheDevice = " + cacheDevice +
                    ",\n" + otaManager);
            if (null != cacheDevice) {
                if (cacheDevice.getState() < remoteDevice.getState()) { //更新设备状态
                    cacheDevice.setState(remoteDevice.getState());
                }
                continue;
            }
            deviceList.add(remoteDevice); //新增设备
            if (otaManager == null) {     //增加OTAManager
                OTAOption option = new OTAOption(channel)
                        .setUseAuthProgress(mConfigHelper.isUseAuth())
                        .setDeviceAuthPass(remoteDevice.isAuthPass());
                otaManager = new OTAManager(option);
                otaManager.addOnRcspCallback(new OnRcspCallback() {
                    @Override
                    public void onRcspInit(Device device, boolean isInit) {
                        super.onRcspInit(device, isInit);
                        Jlog.i(tag, "onRcspInit : " + device + ", isInit : " + isInit);
                        if (isInit) {  //初始化协议成功
                            OTADevice otaDevice = (OTADevice) device;
                            RemoteDevice remoteDevice = findRemoteDeviceByChannel(otaDevice.getChannelSeq());
                            if (null == remoteDevice) {
                                Jlog.w(tag, "onRcspInit : not found device");
                                return;
                            }
                            remoteDevice.setState(OTAConstant.STATE_DEVICE_INIT_RCSP);
                            callbackRemoteDevices();
                        }
                    }

                    @Override
                    public void onMandatoryUpgrade(Device device) {
                        super.onMandatoryUpgrade(device);
                        Jlog.w(tag, "onMandatoryUpgrade : " + device);
                        OTADevice otaDevice = (OTADevice) device;
                        RemoteDevice remoteDevice = findRemoteDeviceByOTADevice(otaDevice);
                        if (null == remoteDevice) {
                            Jlog.w(tag, "onMandatoryUpgrade : not found device");
                            return;
                        }
                        remoteDevice.setState(OTAConstant.STATE_DEVICE_MANDATORY_UPGRADE);
                        callbackRemoteDevices();
                    }
                });
                if (channel == RemoteDevice.CHANNEL_USB) {
                    dongleOTAManager = otaManager;
                } else {
                    otaManagerMap.put(channel, otaManager);
                }
            }
        }
        for (RemoteDevice device : deviceList) {
            RemoteDevice onlineDevice = findRemoteDeviceByChannel(remoteDevices, device.getChannelID());
            if (null != onlineDevice) { //已处理，跳过
                continue;
            }
            device.setState(OTAConstant.STATE_DEVICE_OFFLINE); //设置为下线状态
        }
        callbackRemoteDevices();
    }

    private void callbackRemoteDevices() {
        Jlog.w(tag, "callbackRemoteDevices : " + deviceList);
        mCallbackHelper.onRemoteDevicesChange(deviceList);
    }

    private void registerUsbReceiver() {
        if (null == mUsbReceiver) {
            mUsbReceiver = new UsbReceiver();
            IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
            filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
            filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
            context.registerReceiver(mUsbReceiver, filter);
        }
    }

    private void unregisterUsbReceiver() {
        if (mUsbReceiver != null) {
            context.unregisterReceiver(mUsbReceiver);
            mUsbReceiver = null;
        }
    }

    private final OnDongleEventListener mDongleEventListener = new OnDongleEventListener() {

        @Override
        public void onCommandNotify(BaseCommand command) {
            super.onCommandNotify(command);
            if (command.getCmdType() == Command.BLUETOOTH_STATE) { //通知设备状态更新
                BluetoothStateCmd cmd = (BluetoothStateCmd) command;
                List<BluetoothStateCmd.State> states = cmd.getDeviceStates();
                if (states == null || states.isEmpty()) {
                    Jlog.w(tag, "BLUETOOTH_STATE : not state.");
                    return;
                }
                for (BluetoothStateCmd.State state : states) {
                    Jlog.d(tag, String.format(Locale.getDefault(), "BLUETOOTH_STATE : state channel = %d, state = %d",
                            state.getDeviceChannel(), state.getStatus()));
                    if (state.getStatus() == OTAConstant.STATE_DEVICE_OFFLINE) { //下线处理
                        RemoteDevice cacheDevice = findRemoteDeviceByChannel(state.getDeviceChannel());
                        if (cacheDevice != null) {
                            Jlog.d(tag, String.format(Locale.getDefault(), "cacheDevice = %s, offline.", cacheDevice));
                            Toast.makeText(context.getApplicationContext(), context.getString(R.string.device_offline, cacheDevice.getDeviceName(),
                                    cacheDevice.getChannelID()), Toast.LENGTH_LONG).show();
                            if (removeOtaManager(state.getDeviceChannel())) {
                                deviceList.remove(cacheDevice);
                            }
                        }
                    }
                }
                //回复通知设备状态
                cmd.setChannel(Command.Channel.RESPONSE);
                send(cmd, null);
                //请求更新在线设备信息
                obtainOnLineDevices(null);
            }
        }

        @Override
        public void onRcspNotify(RcspCmd command) {
            super.onRcspNotify(command);
            Jlog.i(tag, "onRcspNotify : " + command);
            mCallbackHelper.onRcspData(command.getChannel(), command.getRcspData());
        }

        @Override
        public void onError(ErrorCode errorCode) {
            super.onError(errorCode);
            mCallbackHelper.onError(errorCode.code, errorCode.message);
        }
    };

    private class UsbReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (null == intent || null == intent.getAction()) return;
            switch (intent.getAction()) {
                case ACTION_USB_PERMISSION: {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    boolean isGranted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                    Jlog.w(tag, "ACTION_USB_PERMISSION : isGranted = " + isGranted + ", device = " + device);
                    if (isGranted && device != null) {
                        for (int i = 0; i < device.getInterfaceCount(); i++) {
                            UsbInterface usbInterface = device.getInterface(i);
                            if (usbInterface.getInterfaceClass() == Const.INTERFACE_CLASS_HID) {
                                Jlog.w(tag, "Grant permission and open it.");
                                if (mOpenUsbParam != null) {
                                    tryToOpenUsbDevice(device, mOpenUsbParam.getListener());
                                }
                                break;
                            }
                        }
                    } else {
                        Jlog.w(tag, "Permission denied!" + mOpenUsbParam);
                        setUsbDevice(null);
                        if (mOpenUsbParam != null && mOpenUsbParam.getListener() != null)
                            mOpenUsbParam.getListener().onFailed(DongleError.ERR_PERMISSION_DENIED, "Permission denied!");
                    }
                    setOpenUsbParam(null);
                    break;
                }
                case UsbManager.ACTION_USB_DEVICE_DETACHED: {  //Usb Device offline
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    Jlog.w(tag, "detached = " + device + ",\n OpenUsbDevice = " + getOpenUsbDevice()
                            + ", " + (device != null && device.equals(getOpenUsbDevice())));
                    mCallbackHelper.onUsbDeviceState(device, false);
                    if (device != null && device.equals(getOpenUsbDevice())) {
                        closeUseDevice(device);
                    }
                    closeOpenUsvDevice();
                    break;
                }
                case UsbManager.ACTION_USB_DEVICE_ATTACHED: { //Usb Device online
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    Jlog.w(tag, "attached = " + device);
                    mCallbackHelper.onUsbDeviceState(device, true);
                    break;
                }
            }
        }
    }

    private static class BooleanCommandCallback extends CommandCallback {
        private final OnResultListener<Boolean> listener;

        public BooleanCommandCallback(OnResultListener<Boolean> listener) {
            this.listener = listener;
        }

        @Override
        public void onSent(BaseCommand command) {
            if (null != listener) listener.onResult(true);
        }

        @Override
        public void onError(ErrorCode code) {
            if (null != listener) listener.onFailed(code.code, code.message);
        }
    }

    private class OpenUsbDeviceTask extends Thread {
        private final UsbDevice device;
        private final OnResultListener<UsbDevice> listener;
        private final Handler mUIHandler = new Handler(Looper.getMainLooper());

        public OpenUsbDeviceTask(UsbDevice device, OnResultListener<UsbDevice> listener) {
            this.device = device;
            this.listener = listener;
        }

        @Override
        public void run() {
            if (null == device) {
                callbackFailed(DongleError.ERR_NOT_FOUNT_DEVICE, "Not found usb device.");
                return;
            }
            open(device, new UsbCallback() {
                @Override
                public void onSuccess() {
                    Jlog.d(tag, "tryToOpenUsbDevice : Open Usb success");
                    setEventListener(mDongleEventListener);
                    final Runnable CmdTimeoutTask = () -> {
                        Jlog.w(tag, "01 cmd response is timeout." + getDongleInfo());
                        callbackSuccess();
                    };
                    //获取设备信息
                    getDongleInfo(new OnResultListener<DongleInfo>() {
                        @Override
                        public void onResult(DongleInfo result) {
                            Jlog.d(tag, "getDongleInfo : >>>>" + result);
                            mUIHandler.removeCallbacks(CmdTimeoutTask);
                            setDongleInfo(result);
                            callbackSuccess();
                        }

                        @Override
                        public void onFailed(int code, String message) {
                            Jlog.e(tag, "getDongleInfo : error:" + code + ", " + message);
                            mUIHandler.removeCallbacks(CmdTimeoutTask);
                            setDongleInfo(null);
                            callbackSuccess();
                        }
                    });
                    //设置命令超时 - 3秒
                    mUIHandler.postDelayed(CmdTimeoutTask, 3 * 1000);
                }

                @Override
                public void onFailure(ErrorCode errorCode) {
                    Jlog.e(tag, "tryToOpenUsbDevice : error:" + errorCode);
                    String message = "code = " + errorCode.getCode() + ", " + errorCode.getMessage();
                    callbackFailed(DongleError.ERR_OPEN_USB, message);
                }
            });
        }

        private void callbackSuccess() {
            setUsbDevice(device);
            if (listener != null) {
                mUIHandler.post(() -> listener.onResult(device));
            }
            setOpenUsbParam(null);
            mOpenUsbDeviceTask = null;
        }

        private void callbackFailed(int code, String message) {
            if (listener != null) {
                mUIHandler.post(() -> listener.onFailed(code, message));
            }
            setDongleInfo(null);
            setUsbDevice(null);
            setOpenUsbParam(null);
            mOpenUsbDeviceTask = null;
        }
    }
}
