package com.jieli.ota.tool.dongle.callback;

import android.hardware.usb.UsbDevice;

import com.jieli.ota.tool.dongle.model.DongleInfo;
import com.jieli.ota.tool.dongle.model.RemoteDevice;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc Dongle 操作
 * @since 2022/4/29
 */
public interface IDongleOp {

    UsbDevice getOpenUsbDevice();

    DongleInfo getDongleInfo();

    void addOnDongleEventCallback(OnDongleEventCallback callback);

    void removeOnDongleEventCallback(OnDongleEventCallback callback);

    void openUsbDevice(int vid, int pid, OnResultListener<UsbDevice> listener);

    void closeUseDevice(UsbDevice device);

    void sendRcspData(RemoteDevice device, byte[] data, OnResultListener<Boolean> listener);

    void getDongleInfo(OnResultListener<DongleInfo> listener);

    void obtainOnLineDevices(OnResultListener<Boolean> listener);

    void connectRemoteDevice(RemoteDevice device, OnResultListener<Boolean> listener);

    void disconnectRemoteDevice(int channel, OnResultListener<Boolean> listener);

    void setChannelAuthFlag(int channel, boolean isAuthPass, OnResultListener<Boolean> listener);
}
