package com.jieli.ota.data.model;

import com.jieli.ota.data.constant.OTAConstant;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OTA完成状态
 * @since 2022/5/6
 */
public class OTAFinishState extends OtaState {
    private final int code;
    private final String message;

    public OTAFinishState(int channel, int code, String message) {
        super(channel, OTAConstant.STATE_DEVICE_OTA_FINISH);
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return "OTAFinishState{" +
                "code=" + code +
                ", message='" + message + '\'' +
                "} " + super.toString();
    }
}
