package com.jieli.ota.util;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 保存打印文件任务
 * @since 2022/5/18
 */
public class SaveLogTask extends Thread {
    private final String dirPath;                                                  //上下文, 用于创建Log文件
    private final LinkedBlockingDeque<String> queue = new LinkedBlockingDeque<>();  //打印信息缓存队列

    public static int LOG_FILE_SIZE_LIMIT = 300 * 1024 * 1024;
    @SuppressLint("ConstantLocale")
    private static final SimpleDateFormat yyyyMMdd_HHmmss = new SimpleDateFormat(
            "yyyyMMddHHmmss", Locale.getDefault());

    private volatile boolean isRunning; //是否运行
    private volatile boolean isLock;    //是否阻塞标志
    private volatile long fileSize;     //打印文件大小

    public SaveLogTask(String dirPath) {
        this.dirPath = dirPath;
    }

    public boolean isRunning() {
        return isRunning;
    }

    public synchronized void stopRunning() {
        isRunning = false;
        unLock();
    }

    public void addLogMessage(String message) {
        if (null == message || message.length() == 0) return;
        boolean ret = false;
        try {
            queue.put(message);
            ret = true;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (ret) {
            unLock();
        }
    }

    @Override
    public void run() {
        super.run();
        //创建Log文件
        FileOutputStream outputStream = createLogFile();
        if (outputStream == null) return;
        isRunning = true;
        synchronized (queue) {
            while (isRunning) {
                if (queue.isEmpty()) {
                    lock();
                } else {
                    String message = queue.poll();
                    if (message == null) continue;
                    try {
                        outputStream.write(message.getBytes());
                        fileSize += message.getBytes().length;
                    } catch (IOException e) {
                        e.printStackTrace();
                        isRunning = false;
                    }
                    if (LOG_FILE_SIZE_LIMIT > 0 && fileSize > LOG_FILE_SIZE_LIMIT) { //打印文件大小限制
                        outputStream = createLogFile();
                    }
                }
            }
        }
        if (null != outputStream) {
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        queue.clear();
        isRunning = false;
    }

    private void lock() {
        synchronized (queue) {
            if (isLock) return;
            isLock = true;
            try {
                queue.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            isLock = false;
        }
    }

    private void unLock() {
        synchronized (queue) {
            if (!isLock) return;
            queue.notify();
        }
    }

    private FileOutputStream createLogFile() {
        FileOutputStream output = null;
        try {
            String logFilePath = dirPath + "/ota_log_" + getTimestampString() + ".txt";
            output = new FileOutputStream(logFilePath, true);
            File file = new File(logFilePath);
            fileSize = file.exists() ? file.length() : 0;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return output;
    }

    @NonNull
    private String getTimestampString() {
        return yyyyMMdd_HHmmss.format(Calendar.getInstance().getTime());
    }
}
