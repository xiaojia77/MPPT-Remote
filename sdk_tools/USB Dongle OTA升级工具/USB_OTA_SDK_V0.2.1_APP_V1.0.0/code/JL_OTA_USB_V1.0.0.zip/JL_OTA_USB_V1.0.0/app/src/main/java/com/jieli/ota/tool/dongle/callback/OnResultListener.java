package com.jieli.ota.tool.dongle.callback;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 结果监听器
 * @since 2022/4/29
 */
public interface OnResultListener<T> {

    void onResult(T result);

    void onFailed(int code, String message);
}
