package com.jieli.ota.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc UI辅助工具类
 * @since 2022/5/5
 */
public class UIHelper {

    /**
     * 创建文件路径
     *
     * @param context  上下文
     * @param dirNames 文件夹名
     * @return 路径
     */
    public static String createFilePath(Context context, String... dirNames) {
        if (context == null || dirNames == null || dirNames.length == 0) return null;
        File file = context.getExternalFilesDir(null);
        if (file == null || !file.exists()) return null;
        StringBuilder filePath = new StringBuilder(file.getPath());
        if (filePath.toString().endsWith("/")) {
            filePath = new StringBuilder(filePath.substring(0, filePath.lastIndexOf("/")));
        }
        for (String dirName : dirNames) {
            filePath.append("/").append(dirName);
            file = new File(filePath.toString());
            if (!file.exists() || file.isFile()) {//文件不存在
                if (!file.mkdir()) {
                    Log.w("jieli", "create dir failed. filePath = " + filePath);
                    break;
                }
            }
        }
        return filePath.toString();
    }

    /**
     * 获取文件大小描述
     *
     * @param fileSize 文件大小
     * @return 体积描述
     */
    public static String getFileSizeDesc(long fileSize) {
        if (fileSize >= 1024 * 1024) {
            double value = fileSize / (1024.0 * 1024.0);
            return String.format(Locale.getDefault(), "%.1f MB", value);
        } else {
            double value = fileSize / 1024.0;
            return String.format(Locale.getDefault(), "%.1f KB", value);
        }
    }


    /**
     * dp covert to px
     *
     * @param context 上下文
     * @param dp      dp
     */
    public static int dp2px(Context context, int dp) {
        if (context == null) {
            throw new RuntimeException("context is null");
        }
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                context.getResources().getDisplayMetrics());
    }

    /**
     * 获取App名称
     */
    public static String getAppName(Context context) {
        PackageManager pm = context.getPackageManager();
        CharSequence name = pm.getApplicationLabel(context.getApplicationInfo());
        if (TextUtils.isEmpty(name)) {
            throw new RuntimeException("app名称读取失败");
        } else {
            return name.toString();
        }
    }

    /**
     * 获取版本名
     */
    public static String getVersionName(Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            return pm.getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return "default_version_name";
    }

    /**
     * 获取文件名
     *
     * @param filePath 文件路径
     * @return 文件名
     */
    public static String getFileName(String filePath) {
        if (filePath == null || filePath.equals("/")) return null;
        String fileName;
        if (filePath.endsWith("/")) {
            filePath = filePath.substring(0, filePath.lastIndexOf("/"));
        }
        fileName = filePath;
        int index = filePath.lastIndexOf("/");
        if (index != -1 && index + 1 < filePath.length()) {
            fileName = filePath.substring(index + 1);
        }
        return fileName;
    }


    private static long lastClickTime = 0;
    private final static long DOUBLE_CLICK_INTERVAL = 2000; //2 s

    public static boolean isFastDoubleClick() {
        return isFastDoubleClick(DOUBLE_CLICK_INTERVAL);
    }

    public static boolean isFastDoubleClick(long interval) {
        boolean isDoubleClick = false;
        long currentTime = new Date().getTime();
        if (currentTime - lastClickTime <= interval) {
            isDoubleClick = true;
        }
        lastClickTime = currentTime;
        return isDoubleClick;
    }

    /**
     * 设置沉浸式状态栏。
     *
     * @param mWindow      当前Activity的Window对象。
     * @param isLightState 设置状态栏是否为浅色，状态栏浅色则字体为深黑色，状态栏深色则字体白色，
     */
    public static void setImmersiveStateBar(Window mWindow, boolean isLightState) {
        if (mWindow != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            int option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

            mWindow.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            View view = mWindow.getDecorView();
            if (view != null) {
                view.setSystemUiVisibility(option);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mWindow.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                        | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
                mWindow.setStatusBarColor(Color.TRANSPARENT);
            }
            if (isLightState) {
                String phoneManufacturer = android.os.Build.BRAND;
                if (!TextUtils.isEmpty(phoneManufacturer)) {
//                    Logcat.i(TAG, "phoneManufacturer : " + phoneManufacturer);
                    if (phoneManufacturer.contains("Meizu") || phoneManufacturer.contains("meizu")) {
                        if (FlymeSetStatusBarLightMode(mWindow, true)) {
                            return;
                        }
                    } else if (phoneManufacturer.contains("Xiaomi") || phoneManufacturer.contains("xiaomi")) {
                        if (MIUISetStatusBarLightMode(mWindow, true)) {
                            return;
                        }
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    mWindow.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                }
            }
        }
    }

    /**
     * 设置状态栏图标为深色和魅族特定的文字风格
     * 可以用来判断是否为Flyme用户
     *
     * @param window 需要设置的窗口
     * @param dark   是否把状态栏文字及图标颜色设置为深色
     * @return boolean 成功执行返回true
     */
    private static boolean FlymeSetStatusBarLightMode(Window window, boolean dark) {
        boolean result = false;
        if (window != null) {
            try {
                WindowManager.LayoutParams lp = window.getAttributes();
                Field darkFlag = WindowManager.LayoutParams.class
                        .getDeclaredField("MEIZU_FLAG_DARK_STATUS_BAR_ICON");
                Field meizuFlags = WindowManager.LayoutParams.class
                        .getDeclaredField("meizuFlags");
                darkFlag.setAccessible(true);
                meizuFlags.setAccessible(true);
                int bit = darkFlag.getInt(null);
                int value = meizuFlags.getInt(lp);
                if (dark) {
                    value |= bit;
                } else {
                    value &= ~bit;
                }
                meizuFlags.setInt(lp, value);
                window.setAttributes(lp);
                result = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    /**
     * 需要MIUIV6以上
     *
     * @param window
     * @param dark   是否把状态栏文字及图标颜色设置为深色
     * @return boolean 成功执行返回true
     */
    private static boolean MIUISetStatusBarLightMode(Window window, boolean dark) {
        boolean result = false;
        if (window != null) {
            Class clazz = window.getClass();
            try {
                int darkModeFlag;
                @SuppressLint("PrivateApi")
                Class layoutParams = Class.forName("android.view.MiuiWindowManager$LayoutParams");
                Field field = layoutParams.getField("EXTRA_FLAG_STATUS_BAR_DARK_MODE");
                darkModeFlag = field.getInt(layoutParams);
                Method extraFlagField = clazz.getMethod("setExtraFlags", int.class, int.class);
                if (dark) {
                    extraFlagField.invoke(window, darkModeFlag, darkModeFlag);//状态栏透明且黑色字体
                } else {
                    extraFlagField.invoke(window, 0, darkModeFlag);//清除黑色字体
                }
                result = true;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    //开发版 7.7.13 及以后版本采用了系统API，旧方法无效但不会报错，所以两个方式都要加上
                    if (dark) {
                        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                    } else {
                        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    @NonNull
    public static String formatOTATime(int time) {
        return String.format(Locale.getDefault(), "%s:%s", formatTime(time / 60), formatTime(time % 60));
    }

    @NonNull
    public static String formatTime(int time) {
        if (time <= 0) {
            return "00";
        } else if (time < 10) {
            return "0" + time;
        } else {
            return String.valueOf(time);
        }
    }

    /**
     * 获取目标文件列表
     *
     * @param dirPath 目录路径
     * @param suffix  后缀
     * @return 目标文件列表
     */
    public static List<File> obtainFileList(String dirPath, String suffix) {
        if (null == dirPath) return null;
        File dir = new File(dirPath);
        if (!dir.exists()) return null;
        List<File> result = new ArrayList<>();
        if (dir.isFile()) {
            if (dirPath.endsWith(suffix)) {
                result.add(dir);
            }
            return result;
        } else {
            File[] fileList = dir.listFiles();
            if (fileList != null) {
                for (File file : fileList) {
                    List<File> files = obtainFileList(file.getPath(), suffix);
                    if (files != null && !files.isEmpty()) {
                        result.addAll(files);
                    }
                }
            }
        }
        return result;
    }
}
