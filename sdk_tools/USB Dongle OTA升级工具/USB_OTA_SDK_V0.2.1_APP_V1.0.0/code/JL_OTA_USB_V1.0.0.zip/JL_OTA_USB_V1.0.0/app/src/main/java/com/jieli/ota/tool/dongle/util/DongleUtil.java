package com.jieli.ota.tool.dongle.util;

import com.jieli.ota.data.constant.OTAConstant;
import com.jieli.ota.tool.dongle.model.RemoteDevice;
import com.jieli.usb.dongle.protocol.cmd.BluetoothDevicesCmd;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zqjasonzhong on 2022/4/30.
 */
public class DongleUtil {

    public static List<RemoteDevice> convertToRemoteDeviceList(List<BluetoothDevicesCmd.Device> devices) {
        if (null == devices || devices.isEmpty()) return new ArrayList<>();
        List<RemoteDevice> list = new ArrayList<>();
        for (BluetoothDevicesCmd.Device device : devices) {
            RemoteDevice remoteDevice = convertRemoteDevice(device, OTAConstant.STATE_DEVICE_ONLINE);
            if (null == remoteDevice) continue;
            if (!list.contains(remoteDevice)) {
                list.add(remoteDevice);
            }
        }
        return list;
    }


    public static RemoteDevice convertRemoteDevice(BluetoothDevicesCmd.Device device, int state) {
        if (null == device) return null;
//        if (!device.isSupportOta()) return null; //不支持OTA
        RemoteDevice remoteDevice = new RemoteDevice(device.getDeviceChannel());
        remoteDevice.setMac(device.getMac());
        remoteDevice.setDeviceName(device.getDeviceName());
        remoteDevice.setState(state);
        remoteDevice.setAuthPass(device.isAuthed());
        return remoteDevice;
    }
}
