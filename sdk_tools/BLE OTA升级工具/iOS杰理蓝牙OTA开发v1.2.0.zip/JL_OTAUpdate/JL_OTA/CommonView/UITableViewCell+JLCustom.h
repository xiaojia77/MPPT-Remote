//
//  UITableViewCell+JLCustom.h
//  JL_OTA
//
//  Created by 凌煊峰 on 2021/10/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITableViewCell (JLCustom)

- (void)setCustomStyle;

@end

NS_ASSUME_NONNULL_END
