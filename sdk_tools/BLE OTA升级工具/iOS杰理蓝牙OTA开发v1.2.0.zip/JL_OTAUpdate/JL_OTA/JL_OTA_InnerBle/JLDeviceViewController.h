//
//  JLDeviceViewController.h
//  JL_OTA_InnerBle
//
//  Created by 凌煊峰 on 2021/10/12.
//

#import <UIKit/UIKit.h>
#import "JLBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface JLDeviceViewController : JLBaseViewController

@end

NS_ASSUME_NONNULL_END
