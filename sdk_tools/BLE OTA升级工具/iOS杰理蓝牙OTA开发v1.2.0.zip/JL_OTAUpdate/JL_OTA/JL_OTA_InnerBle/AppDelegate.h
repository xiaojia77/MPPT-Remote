//
//  AppDelegate.h
//  JL_OTA_InnerBle
//
//  Created by 凌煊峰 on 2021/10/9.
//

#import <UIKit/UIKit.h>
#import <JL_BLEKit/JL_BLEKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property(nonatomic, strong) UIWindow *window;

@end

