//
//  JLUpdateViewController.h
//  JL_OTA
//
//  Created by 凌煊峰 on 2021/10/9.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JLUpdateViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
